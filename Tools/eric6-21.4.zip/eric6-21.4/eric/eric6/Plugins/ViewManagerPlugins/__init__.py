# -*- coding: utf-8 -*-
 
# Copyright (c) 2007 - 2021 Detlev Offenbach <detlev@die-offenbachs.de>
#
 
"""
Package containing the various view manager plugins.
"""
