from PyQt5 import uic
from PyQt5.QtWidgets import QApplication
from PyQt5.QtWidgets import *
from PyQt5.uic import loadUi

from matplotlib.backends.backend_qt5agg import (NavigationToolbar2QT  as  NavigationToolbar)

import numpy  as  np
import random

# Form, Window = uic.loadUiType("mainwindow2.ui")
min = 20
max = 50
min_limit=20
max_limit = 50

class MatplotlibWidget(QMainWindow):

    def __init__(self):
        print("clicked in init")
        QMainWindow.__init__(self)

        loadUi(
            "C:/Users/melmohta/Desktop/Aliya_Co/ALI-SF/Smart-farm/SW/Code/GUI/GUI_project/mainwindow3.ui",
            self)

        self.setWindowTitle("PyQt5 & Matplotlib Example GUI")
        self.register_2.clicked.connect(self.update_graph)
        self.Min_Slider.valueChanged[int].connect(self.Min_Slider_Value)
        self.Max_Slider.valueChanged[int].connect(self.Max_Slider_Value)
        self.Min_En.toggled.connect(self.Min_En_update)
        self.Max_En.toggled.connect(self.Max_En_update)

        # Hvac controller
        self.ht1_B.clicked.connect(self.heater_one)
        self.ht2_B.clicked.connect(self.heater_two)
        self.ht3_B.clicked.connect(self.heater_three)

        self.co1_B.clicked.connect(self.cooler_one)
        self.co2_B.clicked.connect(self.cooler_two)
        self.co3_B.clicked.connect(self.cooler_three)


        self.addToolBar(NavigationToolbar(self.temp_plot.canvas, self))

    def update_graph(self):

        t = [1, 2, 3, 4]


        self.temp_plot.canvas.axes.clear()
        self.temp_plot.canvas.axes.plot(t, [50, 50, 50, 50])
        self.temp_plot.canvas.axes.plot(t, [20, 20, 20, 20])
        self.temp_plot.canvas.axes.plot(t, [15, 20, 30, 40])

        self.temp_plot.canvas.axes.legend(('min', 'max', 'temp'), loc='upper right')
        self.temp_plot.canvas.axes.set_title(' Cosinus - Sinus Signal')
        self.temp_plot.canvas.draw()

    ################################# sub function #################################################
    # this function is update lable of min temp limit from slidr bar aftercheck with check box     #
    #                                                                                              #
    ################################################################################################
    def Min_Slider_Value(self, value):
        print(str(self.Min_En.isChecked()))
        if str(self.Min_En.isChecked()) == "True":
            self.Min_label.setText(str(value)+"°C")
        elif str(self.Min_En.isChecked()) == "False":
            self.Min_label.setText(str(min_limit)+"°C")

    ################################# sub function #################################################
    # this function is update lable of min temp limit from slidr bar 2 aftercheck with check box     #
    #                                                                                              #
    ################################################################################################
    def Max_Slider_Value(self, value):
        print(str(self.Max_En.isChecked()))
        if str(self.Max_En.isChecked()) == "True":
            self.Max_label.setText(str(value)+"°C")
        elif str(self.Max_En.isChecked()) == "False":
            self.Max_label.setText(str(max_limit)+"°C")


    # check bos function
    def Min_En_update(self,state):
        Min_En = self.sender()
        print(str(Min_En.isChecked()))

    # check bos function
    def Max_En_update(self,state):
        Max_En = self.sender()
        print(str(Max_En.isChecked()))

    # cooler and heater button control
    # list of functions
    def heater_one(self):
        print("heater1")

    def heater_two(self):
        print("heater2")

    def heater_three(self):
        print("heater3")

    def cooler_one(self):
        print("cooler1")

    def cooler_two(self):
        print("cooler2")

    def cooler_three(self):
        print("cooler3")

def task():
    print("print me in task")


if __name__ == '__main__':
    app = QApplication([])
    # form = Form()
    task()
    window = MatplotlibWidget()
    print("clicked")
    # form.setupUi(window)
    window.show()
    app.exec()





