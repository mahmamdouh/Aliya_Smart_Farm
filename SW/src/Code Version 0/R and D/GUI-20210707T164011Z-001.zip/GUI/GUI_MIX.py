from PyQt5 import QtWidgets, QtCore
from pyqtgraph import PlotWidget, plot
import pyqtgraph as pg
import sys  # We need sys so that we can pass argv to QApplication
import os
from PyQt5 import uic
from PyQt5.QtWidgets import QApplication
from  PyQt5.QtWidgets  import * 
from  PyQt5.uic  import  loadUi

from  matplotlib.backends.backend_qt5agg  import  ( NavigationToolbar2QT  as  NavigationToolbar )

import  numpy  as  np 
import  random




Form, Window = uic.loadUiType("mainwindow2.ui")

class MainWindow(QtWidgets.QMainWindow):

    def __init__(self, *args, **kwargs):
        super(MainWindow, self).__init__(*args, **kwargs)
		loadUi ( "C:/Users/melmohta/Desktop/Aliya_Co/ALI-SF/Smart-farm/SW/Code/GUI/qt_designer.ui" , self )
		#loadUi ( "C:/Users/melmohta/Desktop/Aliya_Co/ALI-SF/Smart-farm/SW/Code/GUI/SampleProgram/mainwindow2.ui", self)
		self . setWindowTitle ( "PyQt5 & Matplotlib Example GUI" )
		self . pushButton_generate_random_signal . clicked . connect ( self . update_graph )
		self . addToolBar ( NavigationToolbar ( self . temp_plot . canvas ,  self ))

        self.graphWidget = pg.PlotWidget()
        self.setCentralWidget(self.graphWidget)

        hour = [1,2,3,4,5,6,7,8,9,10]
        temperature_1 = [30,32,34,32,33,31,29,32,35,45]
        temperature_2 = [50,35,44,22,38,32,27,38,32,44]

        #Add Background colour to white
        self.graphWidget.setBackground('w')
        # Add Title
        self.graphWidget.setTitle("Your Title Here", color="b", size="30pt")
        # Add Axis Labels
        styles = {"color": "#f00", "font-size": "20px"}
        self.graphWidget.setLabel("left", "Temperature (°C)", **styles)
        self.graphWidget.setLabel("bottom", "Hour (H)", **styles)
        #Add legend
        self.graphWidget.addLegend()
        #Add grid
        self.graphWidget.showGrid(x=True, y=True)
        #Set Range
        self.graphWidget.setXRange(0, 10, padding=0)
        self.graphWidget.setYRange(20, 55, padding=0)

        self.plot(hour, temperature_1, "Sensor1", 'r')
        self.plot(hour, temperature_2, "Sensor2", 'b')


    def plot(self, x, y, plotname, color):
        pen = pg.mkPen(color=color)
        self.graphWidget.plot(x, y, name=plotname, pen=pen, symbol='+', symbolSize=30, symbolBrush=(color))
		
	def  update_graph ( self ):

        fs  =  500 
        f  =  random . randint ( 1 ,  100 ) 
        ts  =  1 / fs 
        length_of_signal  =  100 
        t  =  np . linspace ( 0 , 1 , length_of_signal )
        
        cosinus_signal  =  np . cos ( 2 * np . pi * f * t ) 
        sinus_signal  =  np . sin ( 2 * np . pi * f * t )

        self . temp_plot . canvas . axes . clear () 
        self . temp_plot . canvas . axes . plot ( t ,  cosinus_signal ) 
        self . temp_plot . canvas . axes . plot ( t ,  sinus_signal ) 
        self . temp_plot . canvas . axes . legend (( 'cosinus' ,  'sinus' ),loc = 'upper right' ) 
        self . temp_plot . canvas . axes . set_title ( ' Cosinus - Sinus Signal' ) 
        self . temp_plot . canvas . draw ()

def main():
	app = QApplication([])
	window = Window()
	form = Form()
	form.setupUi(window)
	window  =  MatplotlibWidget ()
	window.show()
	app.exec()

if __name__ == '__main__':
    main()