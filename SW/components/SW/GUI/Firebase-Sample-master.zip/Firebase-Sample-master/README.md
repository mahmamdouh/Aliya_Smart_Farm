### Firebase Tutorial

A walkthrough can be found here: https://youtu.be/7Ax3FJBDDoo

Refer to the buildozer.spec file for the proper requirement when compiling an APK.

Created using Python 2.7
