# stringEx: Arduino cstring library

functions to convert cstrings tu numbers or vice versa
functions to manipulate cstrings


