#ifndef _SETTINGS_H_
#define _SETTINGS_H_

char website_uname[20]  = "myname";
char website_upwd[20]   = "mypwd";
char* website_title     = "Abcde";
char* website_url       = "http://Abcde.net";
const char* ssid        = "WLAN-12345";
const char* password    = "wlanpwd";
char* mail_account      = "owner@gmail.com";
char* mail_pwd          = "mailaccountpwd";
char* mailto_emerg      = "emergency@gmail.com";


#endif