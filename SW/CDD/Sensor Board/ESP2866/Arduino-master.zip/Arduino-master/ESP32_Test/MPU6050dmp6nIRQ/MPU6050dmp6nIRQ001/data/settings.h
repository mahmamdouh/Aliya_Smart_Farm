#ifndef _SETTINGS_H_
#define _SETTINGS_H_

char website_uname[20]  = "fp";
char website_upwd[20]   = "tftf42";
char* website_title     = "Zaphod";
char* website_url       = "http://Zaphod.sytes.net";
const char* ssid        = "WLAN-3YA7LD";
const char* password    = "18658446694458594657";
char* mail_account      = "dr.h.wunder@gmail.com";
char* mail_pwd          = "heanfeha1955";
char* mailto_emerg      = "Feluuzzz@gmail.com";


#endif