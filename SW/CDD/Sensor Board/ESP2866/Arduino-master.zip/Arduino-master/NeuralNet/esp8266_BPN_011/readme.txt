neural backpropagation net
ver 0.1.1

derived from version 0.1.0, 
but different, quite challenging training pattern
