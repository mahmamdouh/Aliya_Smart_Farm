7-DOF Robotarm

measures & dimensions:



\   /
 \ /      finger length       50 mm
 |-|  6   claw spread   
  |       metacarpal length   55 mm
  |       
  o   5   metacarpal rotate
  |     
  |       wrist length        95 mm
  |     
  v   4   wrist tilt       
  |       
  |       forearm segment2    50 mm
  |       
  o   3   forearm rotate
  |
  |       forearm segment1   100 mm
  |
  v   2   elbow tilt     
  |       
  |
  |       upper arm length   180 mm
  |
  |         
  v   1   shoulder tilt
  |
  |       shoulder height     15 mm
  o   0   trunc rotate horiz   
  |     
  |       trunc base          85 mm
  |
 ___      floor







