#ifndef _SETTINGS_H_
#define _SETTINGS_H_

char* website_pwd       = "abcdefg";
char* website_title     = "mywebsite";
char* website_url       = "http://mywebsite.de";
const char* ssid        = "WLAN-name";
const char* password    = "123456789";
char* email_notif       = "ich@gmail.com"
char* email_emerg       = "Verwandter@gmail.com"


#endif