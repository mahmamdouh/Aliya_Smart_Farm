This video is the continuation of video in which we send sensor data from Esp8266 to Raspberry Pi. 
In this video we will be sending sensor data from Raspberry Pi to a realtime database called Firebase.

Helpful Commands:
-> udo apt-get update
-> sudo apt-get upgrade
-> sudo apt install -y mosquitto mosquitto-clients

-> mosquitto -v
-> mosquitto -d
-> mosquitto_sub -d -t testing
-> mosquitto_pub -d -t testing -m "Good Day!"

-> pip install paho-mqtt
-> pip install python-firebase

You can check out details tutorial on youtube
https://www.youtube.com/watch?v=qtZcX4swoS4
