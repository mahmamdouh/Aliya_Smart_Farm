In this project we will be creating a Publisher and Subsriber architecture and we will be sending sensors data to a server.
We have used ESP8266 and make it as a client that will take data from sensor and send to a server which is raspberry pi in this case.

Helpful Commands:
-> udo apt-get update
-> sudo apt-get upgrade
-> sudo apt install -y mosquitto mosquitto-clients

-> mosquitto -v
-> mosquitto -d
-> mosquitto_sub -d -t testing
-> mosquitto_pub -d -t testing -m "Good Day!"

-> pip install paho-mqtt



You can check out details tutorial on youtube
https://www.youtube.com/watch?v=OFaow_TPv6s

