<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after
 */
?>
		</div><!-- #content -->
<?php global $hideFooter; if (!$hideFooter) { ?>
        <footer class="u-clearfix u-footer u-grey-80" id="sec-7b44">
  <div class="u-clearfix u-sheet u-sheet-1">
    <div class="u-align-center u-container-style u-group u-group-1">
      <div class="u-container-layout u-valign-middle u-container-layout-1">
        <p class="u-small-text u-text u-text-variant u-text-1">Sample footer text</p>
      </div>
    </div>
  </div>
</footer>
        
<?php } ?>
        
        
	</div><!-- .site-inner -->
</div><!-- #page -->

<?php wp_footer(); ?>
<?php back_to_top(); ?>
</body>
</html>
