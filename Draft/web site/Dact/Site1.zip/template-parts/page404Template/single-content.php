<?php $skip_min_height = false; ?><section class="u-align-center u-clearfix u-section-1" id="sec-3246">
  <div class="u-clearfix u-sheet u-valign-middle u-sheet-1">
    <h1 class="u-text u-text-default u-text-1">404</h1>
    <div class="u-text u-text-default u-text-not-found-message u-text-2"><?php theme_404_content(); ?></div>
    <p class="u-text u-text-3">The page you are looking for was moved, removed, renamed or might never existed</p>
    <a href="" class="u-active-white u-black u-border-2 u-border-active-black u-border-black u-border-hover-black u-btn u-button-style u-hover-white u-text-active-black u-text-body-alt-color u-text-hover-black u-btn-1">Go to homepage</a>
  </div>
</section><?php if ($skip_min_height) { echo "<style> .u-section-1, .u-section-1 .u-sheet {min-height: auto;}</style>"; } ?>
