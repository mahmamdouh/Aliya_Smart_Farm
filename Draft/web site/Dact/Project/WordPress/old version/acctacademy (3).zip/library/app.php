<?php

/**
 * Theme settings
 *
 * @param array $settings
 * @return array
 */
function theme_app_settings($settings) {
    return json_decode(<<<JSON
    {
    "colorScheme": {
        "bodyColors": [
            "#111111",
            "#ffffff"
        ],
        "bgColor": "#ffffff",
        "colors": [
            "#7da2a9",
            "#4c637f",
            "#18181e",
            "#92e4fd",
            "#b8c1cc"
        ],
        "customColors": [
            {
                "color": "#b898ee",
                "status": 0,
                "transparency": 1,
                "index": 0
            },
            {
                "color": "#203885",
                "status": 0,
                "transparency": 1,
                "index": 1
            },
            {
                "color": "#9697cf",
                "status": 0,
                "transparency": 1,
                "index": 2
            },
            {
                "color": "#5b99c9",
                "status": 0,
                "transparency": 1,
                "index": 3
            },
            {
                "color": "#222622",
                "status": 0,
                "transparency": 1,
                "index": 4
            }
        ],
        "shadingContrast": "body-alt-color",
        "whiteContrast": "body-color",
        "bgContrast": "body-color",
        "name": "u11"
    },
    "fontScheme": {
        "name": "custom-font-family-1",
        "default": true,
        "fonts": {
            "heading": "Roboto, sans-serif",
            "text": "Open Sans, sans-serif",
            "accent": "Arial, sans-serif",
            "headingTitle": "Roboto",
            "textTitle": "Open Sans"
        },
        "subset": "arabic"
    },
    "typography": {
        "name": "custom-page-typography-1",
        "title": {
            "font-size": 6,
            "line-height": "1_1",
            "margin-top": 20,
            "margin-bottom": 20,
            "font": "Roboto, sans-serif",
            "font-style": "",
            "text-decoration": "",
            "letter-spacing": "",
            "text-color": "body-color",
            "border-color": "",
            "border-style": "",
            "color": "",
            "border": "",
            "button-shape": "",
            "border-radius": "",
            "underline": "",
            "gradient": "",
            "font-weight": "400"
        },
        "subtitle": {
            "font-size": 4.5,
            "line-height": "1_1",
            "margin-top": 20,
            "margin-bottom": 20,
            "font-weight": "700",
            "text-transform": "uppercase",
            "font": "Ubuntu, sans-serif"
        },
        "h1": {
            "font-weight": "400",
            "font-size": 3,
            "line-height": "1_1",
            "margin-top": 20,
            "margin-bottom": 20
        },
        "h2": {
            "font-size": 1.875,
            "line-height": "1_1",
            "margin-top": 20,
            "margin-bottom": 20,
            "font-style": "",
            "text-decoration": "",
            "text-transform": "uppercase",
            "letter-spacing": "",
            "text-color": "",
            "border-color": "",
            "border-style": "",
            "color": "",
            "border": "",
            "button-shape": "",
            "border-radius": "",
            "underline": "",
            "gradient": "",
            "font": "Ubuntu, sans-serif",
            "font-weight": 700
        },
        "h3": {
            "font-size": 4.5,
            "line-height": "1_2",
            "margin-top": 20,
            "margin-bottom": 20,
            "font": "Ubuntu, sans-serif",
            "text-transform": "uppercase",
            "font-style": "",
            "text-decoration": "",
            "letter-spacing": 5,
            "text-color": "body-alt-color",
            "border-color": "",
            "border-style": "",
            "color": "",
            "border": "",
            "button-shape": "",
            "border-radius": "",
            "underline": "",
            "gradient": "",
            "font-weight": "700",
            "list-icon-src": "",
            "list-icon-spacing": "0.3",
            "list-icon-size": "0.8"
        },
        "h4": {
            "font-size": 1.5,
            "line-height": "1_2",
            "margin-top": 20,
            "margin-bottom": 20,
            "font": "Ubuntu, sans-serif",
            "font-weight": "700",
            "text-transform": "uppercase"
        },
        "h5": {
            "font-weight": "400",
            "font-size": 1.25,
            "line-height": "1_2",
            "margin-top": 20,
            "margin-bottom": 20
        },
        "h6": {
            "font-weight": "400",
            "font-size": 1.125,
            "line-height": "1_2",
            "margin-top": 20,
            "margin-bottom": 20
        },
        "largeText": {
            "font-size": 1.25,
            "margin-top": 20,
            "margin-bottom": 20
        },
        "smallText": {
            "font-size": 0.875,
            "margin-top": 20,
            "margin-bottom": 20
        },
        "text": {
            "margin-top": 20,
            "margin-bottom": 20
        },
        "link": {},
        "button": {
            "color": "palette-1-base",
            "margin-top": 20,
            "margin-bottom": 20
        },
        "blockquote": {
            "font-style": "italic",
            "indent": 20,
            "border": 4,
            "border-color": "palette-1-base",
            "margin-top": 20,
            "margin-bottom": 20
        },
        "metadata": {
            "margin-top": 20,
            "margin-bottom": 20
        },
        "list": {
            "margin-top": 20,
            "margin-bottom": 20
        },
        "orderedlist": {
            "margin-top": 20,
            "margin-bottom": 20
        },
        "postContent": {
            "margin-top": 20,
            "margin-bottom": 20
        },
        "theme": {
            "gradient": "",
            "image": ""
        },
        "htmlBaseSize": 16,
        "hyperlink": {
            "text-color": "palette-1-base"
        }
    }
}
JSON
, true);
}
add_filter('np_theme_settings', 'theme_app_settings');

function theme_analytics() {
?>
    <?php $GLOBALS['googleAnalyticsMarker'] = false; ?>
<?php
}
add_action('wp_head', 'theme_analytics', 0);


function theme_favicon() {
    $custom_favicon_id = get_theme_mod('custom_favicon');
    @list($favicon_src, ,) = wp_get_attachment_image_src($custom_favicon_id, 'full');
    if (!$favicon_src) {
        $favicon_src = "";
        if ($favicon_src) {
            $favicon_src = get_template_directory_uri() . '/images/' . $favicon_src;
        }
    }

    if ($favicon_src) {
        echo "<link rel=\"icon\" href=\"$favicon_src\">";
    }
}
add_action('wp_head', 'theme_favicon');