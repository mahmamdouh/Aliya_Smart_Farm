<style id="color-scheme" color-scheme="u11" color-style="multicolor-1">.u-body {
--none: transparent;
--none-darker: transparent;
--none-r: 255;
--none-g: 255;
--none-b: 255;
--none-contrast: body-color;
--none-contrast-darker: body-color;
--none-text-color: var(--body-color);
--custom-color-1: #b898ee;
--custom-color-1-darker: #a177e8;
--custom-color-1-r: 184;
--custom-color-1-g: 152;
--custom-color-1-b: 238;
--custom-color-1-contrast: white;
--custom-color-1-contrast-darker: white;
--custom-color-1-text-color: var(--body-alt-color);
--custom-color-2: #203885;
--custom-color-2-darker: #1d3278;
--custom-color-2-r: 32;
--custom-color-2-g: 56;
--custom-color-2-b: 133;
--custom-color-2-contrast: white;
--custom-color-2-contrast-darker: white;
--custom-color-2-text-color: var(--body-alt-color);
--custom-color-3: #9697cf;
--custom-color-3-darker: #7e7fc4;
--custom-color-3-r: 150;
--custom-color-3-g: 151;
--custom-color-3-b: 207;
--custom-color-3-contrast: white;
--custom-color-3-contrast-darker: white;
--custom-color-3-text-color: var(--body-alt-color);
--custom-color-4: #26c8d3;
--custom-color-4-darker: #22b4be;
--custom-color-4-r: 38;
--custom-color-4-g: 200;
--custom-color-4-b: 211;
--custom-color-4-contrast: white;
--custom-color-4-contrast-darker: white;
--custom-color-4-text-color: var(--body-alt-color);
--custom-color-5: #222622;
--custom-color-5-darker: #1f221f;
--custom-color-5-r: 34;
--custom-color-5-g: 38;
--custom-color-5-b: 34;
--custom-color-5-contrast: white;
--custom-color-5-contrast-darker: white;
--custom-color-5-text-color: var(--body-alt-color);
--custom-color-6: #47b8da;
--custom-color-6-darker: #2fafd5;
--custom-color-6-r: 71;
--custom-color-6-g: 184;
--custom-color-6-b: 218;
--custom-color-6-contrast: white;
--custom-color-6-contrast-darker: white;
--custom-color-6-text-color: var(--body-alt-color);
--body-color: #111111;
--body-color-darker: #0f0f0f;
--body-color-r: 17;
--body-color-g: 17;
--body-color-b: 17;
--body-color-contrast: white;
--body-color-contrast-darker: white;
--body-color-text-color: var(--body-alt-color);
--body-alt-color: #ffffff;
--body-alt-color-darker: #e6e6e6;
--body-alt-color-r: 255;
--body-alt-color-g: 255;
--body-alt-color-b: 255;
--body-alt-color-contrast: black;
--body-alt-color-contrast-darker: black;
--body-alt-color-text-color: var(--body-color);
--bg-color: #ffffff;
--bg-color-darker: #e6e6e6;
--bg-color-r: 255;
--bg-color-g: 255;
--bg-color-b: 255;
--bg-color-contrast: black;
--bg-color-contrast-darker: black;
--bg-color-text-color: var(--body-color);
--palette-1-base: #7da2a9;
--palette-1-base-darker: #6b959d;
--palette-1-base-r: 125;
--palette-1-base-g: 162;
--palette-1-base-b: 169;
--palette-1-base-contrast: white;
--palette-1-base-contrast-darker: white;
--palette-1-base-text-color: var(--body-alt-color);
--palette-1-dark-3: #293133;
--palette-1-dark-3-darker: #252c2e;
--palette-1-dark-3-r: 41;
--palette-1-dark-3-g: 49;
--palette-1-dark-3-b: 51;
--palette-1-dark-3-contrast: white;
--palette-1-dark-3-contrast-darker: white;
--palette-1-dark-3-text-color: var(--body-alt-color);
--palette-1-dark-2: #46575a;
--palette-1-dark-2-darker: #3f4e51;
--palette-1-dark-2-r: 70;
--palette-1-dark-2-g: 87;
--palette-1-dark-2-b: 90;
--palette-1-dark-2-contrast: white;
--palette-1-dark-2-contrast-darker: white;
--palette-1-dark-2-text-color: var(--body-alt-color);
--palette-1-dark-1: #637d82;
--palette-1-dark-1-darker: #597075;
--palette-1-dark-1-r: 99;
--palette-1-dark-1-g: 125;
--palette-1-dark-1-b: 130;
--palette-1-dark-1-contrast: white;
--palette-1-dark-1-contrast-darker: white;
--palette-1-dark-1-text-color: var(--body-alt-color);
--palette-1: #7da2a9;
--palette-1-darker: #6b959d;
--palette-1-r: 125;
--palette-1-g: 162;
--palette-1-b: 169;
--palette-1-contrast: white;
--palette-1-contrast-darker: white;
--palette-1-text-color: var(--body-alt-color);
--palette-1-light-1: #9fbdc3;
--palette-1-light-1-darker: #89aeb5;
--palette-1-light-1-r: 159;
--palette-1-light-1-g: 189;
--palette-1-light-1-b: 195;
--palette-1-light-1-contrast: white;
--palette-1-light-1-contrast-darker: white;
--palette-1-light-1-text-color: var(--body-alt-color);
--palette-1-light-2: #c6d9dd;
--palette-1-light-2-darker: #acc8cd;
--palette-1-light-2-r: 198;
--palette-1-light-2-g: 217;
--palette-1-light-2-b: 221;
--palette-1-light-2-contrast: black;
--palette-1-light-2-contrast-darker: black;
--palette-1-light-2-text-color: var(--body-color);
--palette-1-light-3: #f0f5f6;
--palette-1-light-3-darker: #d2e1e4;
--palette-1-light-3-r: 240;
--palette-1-light-3-g: 245;
--palette-1-light-3-b: 246;
--palette-1-light-3-contrast: black;
--palette-1-light-3-contrast-darker: black;
--palette-1-light-3-text-color: var(--body-color);
--palette-2-base: #4c637f;
--palette-2-base-darker: #445972;
--palette-2-base-r: 76;
--palette-2-base-g: 99;
--palette-2-base-b: 127;
--palette-2-base-contrast: white;
--palette-2-base-contrast-darker: white;
--palette-2-base-text-color: var(--body-alt-color);
--palette-2-dark-3: #292d33;
--palette-2-dark-3-darker: #25292e;
--palette-2-dark-3-r: 41;
--palette-2-dark-3-g: 45;
--palette-2-dark-3-b: 51;
--palette-2-dark-3-contrast: white;
--palette-2-dark-3-contrast-darker: white;
--palette-2-dark-3-text-color: var(--body-alt-color);
--palette-2-dark-2: #3e4a59;
--palette-2-dark-2-darker: #384350;
--palette-2-dark-2-r: 62;
--palette-2-dark-2-g: 74;
--palette-2-dark-2-b: 89;
--palette-2-dark-2-contrast: white;
--palette-2-dark-2-contrast-darker: white;
--palette-2-dark-2-text-color: var(--body-alt-color);
--palette-2-dark-1: #4c637f;
--palette-2-dark-1-darker: #445972;
--palette-2-dark-1-r: 76;
--palette-2-dark-1-g: 99;
--palette-2-dark-1-b: 127;
--palette-2-dark-1-contrast: white;
--palette-2-dark-1-contrast-darker: white;
--palette-2-dark-1-text-color: var(--body-alt-color);
--palette-2: #85a0c1;
--palette-2-darker: #6f8fb6;
--palette-2-r: 133;
--palette-2-g: 160;
--palette-2-b: 193;
--palette-2-contrast: white;
--palette-2-contrast-darker: white;
--palette-2-text-color: var(--body-alt-color);
--palette-2-light-1: #a6bbd4;
--palette-2-light-1-darker: #8da8c8;
--palette-2-light-1-r: 166;
--palette-2-light-1-g: 187;
--palette-2-light-1-b: 212;
--palette-2-light-1-contrast: white;
--palette-2-light-1-contrast-darker: white;
--palette-2-light-1-text-color: var(--body-alt-color);
--palette-2-light-2: #cad7e6;
--palette-2-light-2-darker: #adc1d8;
--palette-2-light-2-r: 202;
--palette-2-light-2-g: 215;
--palette-2-light-2-b: 230;
--palette-2-light-2-contrast: black;
--palette-2-light-2-contrast-darker: black;
--palette-2-light-2-text-color: var(--body-color);
--palette-2-light-3: #f1f5f9;
--palette-2-light-3-darker: #cfddea;
--palette-2-light-3-r: 241;
--palette-2-light-3-g: 245;
--palette-2-light-3-b: 249;
--palette-2-light-3-contrast: black;
--palette-2-light-3-contrast-darker: black;
--palette-2-light-3-text-color: var(--body-color);
--palette-3-base: #18181e;
--palette-3-base-darker: #16161b;
--palette-3-base-r: 24;
--palette-3-base-g: 24;
--palette-3-base-b: 30;
--palette-3-base-contrast: white;
--palette-3-base-contrast-darker: white;
--palette-3-base-text-color: var(--body-alt-color);
--palette-3-dark-3: #292933;
--palette-3-dark-3-darker: #25252e;
--palette-3-dark-3-r: 41;
--palette-3-dark-3-g: 41;
--palette-3-dark-3-b: 51;
--palette-3-dark-3-contrast: white;
--palette-3-dark-3-contrast-darker: white;
--palette-3-dark-3-text-color: var(--body-alt-color);
--palette-3-dark-2: #41414c;
--palette-3-dark-2-darker: #3b3b44;
--palette-3-dark-2-r: 65;
--palette-3-dark-2-g: 65;
--palette-3-dark-2-b: 76;
--palette-3-dark-2-contrast: white;
--palette-3-dark-2-contrast-darker: white;
--palette-3-dark-2-text-color: var(--body-alt-color);
--palette-3-dark-1: #6f6f7b;
--palette-3-dark-1-darker: #64646f;
--palette-3-dark-1-r: 111;
--palette-3-dark-1-g: 111;
--palette-3-dark-1-b: 123;
--palette-3-dark-1-contrast: white;
--palette-3-dark-1-contrast-darker: white;
--palette-3-dark-1-text-color: var(--body-alt-color);
--palette-3: #a3a3a9;
--palette-3-darker: #929299;
--palette-3-r: 163;
--palette-3-g: 163;
--palette-3-b: 169;
--palette-3-contrast: white;
--palette-3-contrast-darker: white;
--palette-3-text-color: var(--body-alt-color);
--palette-3-light-1: #bebec3;
--palette-3-light-1-darker: #aaaab1;
--palette-3-light-1-r: 190;
--palette-3-light-1-g: 190;
--palette-3-light-1-b: 195;
--palette-3-light-1-contrast: black;
--palette-3-light-1-contrast-darker: white;
--palette-3-light-1-text-color: var(--body-color);
--palette-3-light-2: #d9d9dd;
--palette-3-light-2-darker: #c2c2c8;
--palette-3-light-2-r: 217;
--palette-3-light-2-g: 217;
--palette-3-light-2-b: 221;
--palette-3-light-2-contrast: black;
--palette-3-light-2-contrast-darker: black;
--palette-3-light-2-text-color: var(--body-color);
--palette-3-light-3: #f5f5f6;
--palette-3-light-3-darker: #dbdbdf;
--palette-3-light-3-r: 245;
--palette-3-light-3-g: 245;
--palette-3-light-3-b: 246;
--palette-3-light-3-contrast: black;
--palette-3-light-3-contrast-darker: black;
--palette-3-light-3-text-color: var(--body-color);
--palette-4-base: #92e4fd;
--palette-4-base-darker: #6bdafc;
--palette-4-base-r: 146;
--palette-4-base-g: 228;
--palette-4-base-b: 253;
--palette-4-base-contrast: black;
--palette-4-base-contrast-darker: black;
--palette-4-base-text-color: var(--body-color);
--palette-4-dark-3: #293133;
--palette-4-dark-3-darker: #252c2e;
--palette-4-dark-3-r: 41;
--palette-4-dark-3-g: 49;
--palette-4-dark-3-b: 51;
--palette-4-dark-3-contrast: white;
--palette-4-dark-3-contrast-darker: white;
--palette-4-dark-3-text-color: var(--body-alt-color);
--palette-4-dark-2: #496168;
--palette-4-dark-2-darker: #42575e;
--palette-4-dark-2-r: 73;
--palette-4-dark-2-g: 97;
--palette-4-dark-2-b: 104;
--palette-4-dark-2-contrast: white;
--palette-4-dark-2-contrast-darker: white;
--palette-4-dark-2-text-color: var(--body-alt-color);
--palette-4-dark-1: #5f8e9c;
--palette-4-dark-1-darker: #56808c;
--palette-4-dark-1-r: 95;
--palette-4-dark-1-g: 142;
--palette-4-dark-1-b: 156;
--palette-4-dark-1-contrast: white;
--palette-4-dark-1-contrast-darker: white;
--palette-4-dark-1-text-color: var(--body-alt-color);
--palette-4: #6cb9d1;
--palette-4-darker: #54aec9;
--palette-4-r: 108;
--palette-4-g: 185;
--palette-4-b: 209;
--palette-4-contrast: white;
--palette-4-contrast-darker: white;
--palette-4-text-color: var(--body-alt-color);
--palette-4-light-1: #92e4fd;
--palette-4-light-1-darker: #6bdafc;
--palette-4-light-1-r: 146;
--palette-4-light-1-g: 228;
--palette-4-light-1-b: 253;
--palette-4-light-1-contrast: black;
--palette-4-light-1-contrast-darker: black;
--palette-4-light-1-text-color: var(--body-color);
--palette-4-light-2: #c3f0fe;
--palette-4-light-2-darker: #97e5fd;
--palette-4-light-2-r: 195;
--palette-4-light-2-g: 240;
--palette-4-light-2-b: 254;
--palette-4-light-2-contrast: black;
--palette-4-light-2-contrast-darker: black;
--palette-4-light-2-text-color: var(--body-color);
--palette-4-light-3: #f4fcff;
--palette-4-light-3-darker: #c2eeff;
--palette-4-light-3-r: 244;
--palette-4-light-3-g: 252;
--palette-4-light-3-b: 255;
--palette-4-light-3-contrast: black;
--palette-4-light-3-contrast-darker: black;
--palette-4-light-3-text-color: var(--body-color);
--palette-5-base: #b8c1cc;
--palette-5-base-darker: #a1adbc;
--palette-5-base-r: 184;
--palette-5-base-g: 193;
--palette-5-base-b: 204;
--palette-5-base-contrast: black;
--palette-5-base-contrast-darker: white;
--palette-5-base-text-color: var(--body-color);
--palette-5-dark-3: #292d33;
--palette-5-dark-3-darker: #25292e;
--palette-5-dark-3-r: 41;
--palette-5-dark-3-g: 45;
--palette-5-dark-3-b: 51;
--palette-5-dark-3-contrast: white;
--palette-5-dark-3-contrast-darker: white;
--palette-5-dark-3-text-color: var(--body-alt-color);
--palette-5-dark-2: #555d66;
--palette-5-dark-2-darker: #4d545c;
--palette-5-dark-2-r: 85;
--palette-5-dark-2-g: 93;
--palette-5-dark-2-b: 102;
--palette-5-dark-2-contrast: white;
--palette-5-dark-2-contrast-darker: white;
--palette-5-dark-2-text-color: var(--body-alt-color);
--palette-5-dark-1: #858e99;
--palette-5-dark-1-darker: #75808c;
--palette-5-dark-1-r: 133;
--palette-5-dark-1-g: 142;
--palette-5-dark-1-b: 153;
--palette-5-dark-1-contrast: white;
--palette-5-dark-1-contrast-darker: white;
--palette-5-dark-1-text-color: var(--body-alt-color);
--palette-5: #b8c1cc;
--palette-5-darker: #a1adbc;
--palette-5-r: 184;
--palette-5-g: 193;
--palette-5-b: 204;
--palette-5-contrast: black;
--palette-5-contrast-darker: white;
--palette-5-text-color: var(--body-color);
--palette-5-light-1: #ccd3db;
--palette-5-light-1-darker: #b3bec9;
--palette-5-light-1-r: 204;
--palette-5-light-1-g: 211;
--palette-5-light-1-b: 219;
--palette-5-light-1-contrast: black;
--palette-5-light-1-contrast-darker: black;
--palette-5-light-1-text-color: var(--body-color);
--palette-5-light-2: #e0e5eb;
--palette-5-light-2-darker: #c4ced9;
--palette-5-light-2-r: 224;
--palette-5-light-2-g: 229;
--palette-5-light-2-b: 235;
--palette-5-light-2-contrast: black;
--palette-5-light-2-contrast-darker: black;
--palette-5-light-2-text-color: var(--body-color);
--palette-5-light-3: #f5f7fa;
--palette-5-light-3-darker: #d4dde9;
--palette-5-light-3-r: 245;
--palette-5-light-3-g: 247;
--palette-5-light-3-b: 250;
--palette-5-light-3-contrast: black;
--palette-5-light-3-contrast-darker: black;
--palette-5-light-3-text-color: var(--body-color);
--grey-40: #999999;
--grey-40-darker: #8a8a8a;
--grey-40-r: 153;
--grey-40-g: 153;
--grey-40-b: 153;
--grey-40-contrast: white;
--grey-40-contrast-darker: white;
--grey-40-text-color: var(--body-alt-color);
--grey-30: #b3b3b3;
--grey-30-darker: #a1a1a1;
--grey-30-r: 179;
--grey-30-g: 179;
--grey-30-b: 179;
--grey-30-contrast: white;
--grey-30-contrast-darker: white;
--grey-30-text-color: var(--body-alt-color);
--grey-25: #c0c0c0;
--grey-25-darker: #adadad;
--grey-25-r: 192;
--grey-25-g: 192;
--grey-25-b: 192;
--grey-25-contrast: black;
--grey-25-contrast-darker: white;
--grey-25-text-color: var(--body-color);
--white: #ffffff;
--white-darker: #e6e6e6;
--white-r: 255;
--white-g: 255;
--white-b: 255;
--white-contrast: black;
--white-contrast-darker: black;
--white-text-color: var(--body-color);
--grey-15: #d9d9d9;
--grey-15-darker: #c3c3c3;
--grey-15-r: 217;
--grey-15-g: 217;
--grey-15-b: 217;
--grey-15-contrast: black;
--grey-15-contrast-darker: black;
--grey-15-text-color: var(--body-color);
--grey-10: #e5e5e5;
--grey-10-darker: #cecece;
--grey-10-r: 229;
--grey-10-g: 229;
--grey-10-b: 229;
--grey-10-contrast: black;
--grey-10-contrast-darker: black;
--grey-10-text-color: var(--body-color);
--grey-5: #f2f2f2;
--grey-5-darker: #dadada;
--grey-5-r: 242;
--grey-5-g: 242;
--grey-5-b: 242;
--grey-5-contrast: black;
--grey-5-contrast-darker: black;
--grey-5-text-color: var(--body-color);
--grey-90: #1a1a1a;
--grey-90-darker: #171717;
--grey-90-r: 26;
--grey-90-g: 26;
--grey-90-b: 26;
--grey-90-contrast: white;
--grey-90-contrast-darker: white;
--grey-90-text-color: var(--body-alt-color);
--grey-80: #333333;
--grey-80-darker: #2e2e2e;
--grey-80-r: 51;
--grey-80-g: 51;
--grey-80-b: 51;
--grey-80-contrast: white;
--grey-80-contrast-darker: white;
--grey-80-text-color: var(--body-alt-color);
--grey-75: #404040;
--grey-75-darker: #3a3a3a;
--grey-75-r: 64;
--grey-75-g: 64;
--grey-75-b: 64;
--grey-75-contrast: white;
--grey-75-contrast-darker: white;
--grey-75-text-color: var(--body-alt-color);
--black: #000000;
--black-darker: #000000;
--black-r: 0;
--black-g: 0;
--black-b: 0;
--black-contrast: white;
--black-contrast-darker: white;
--black-text-color: var(--body-alt-color);
--grey-70: #4d4d4d;
--grey-70-darker: #454545;
--grey-70-r: 77;
--grey-70-g: 77;
--grey-70-b: 77;
--grey-70-contrast: white;
--grey-70-contrast-darker: white;
--grey-70-text-color: var(--body-alt-color);
--grey-60: #666666;
--grey-60-darker: #5c5c5c;
--grey-60-r: 102;
--grey-60-g: 102;
--grey-60-b: 102;
--grey-60-contrast: white;
--grey-60-contrast-darker: white;
--grey-60-text-color: var(--body-alt-color);
--grey-50: #808080;
--grey-50-darker: #737373;
--grey-50-r: 128;
--grey-50-g: 128;
--grey-50-b: 128;
--grey-50-contrast: white;
--grey-50-contrast-darker: white;
--grey-50-text-color: var(--body-alt-color);
--grey-dark-3: #212121;
--grey-dark-3-darker: #1e1e1e;
--grey-dark-3-r: 33;
--grey-dark-3-g: 33;
--grey-dark-3-b: 33;
--grey-dark-3-contrast: white;
--grey-dark-3-contrast-darker: white;
--grey-dark-3-text-color: var(--body-alt-color);
--grey-dark-2: #333333;
--grey-dark-2-darker: #2e2e2e;
--grey-dark-2-r: 51;
--grey-dark-2-g: 51;
--grey-dark-2-b: 51;
--grey-dark-2-contrast: white;
--grey-dark-2-contrast-darker: white;
--grey-dark-2-text-color: var(--body-alt-color);
--grey-dark-1: #454545;
--grey-dark-1-darker: #3e3e3e;
--grey-dark-1-r: 69;
--grey-dark-1-g: 69;
--grey-dark-1-b: 69;
--grey-dark-1-contrast: white;
--grey-dark-1-contrast-darker: white;
--grey-dark-1-text-color: var(--body-alt-color);
--grey: #b3b3b3;
--grey-darker: #a1a1a1;
--grey-r: 179;
--grey-g: 179;
--grey-b: 179;
--grey-contrast: white;
--grey-contrast-darker: white;
--grey-text-color: var(--body-alt-color);
--grey-light-1: #d9d9d9;
--grey-light-1-darker: #c3c3c3;
--grey-light-1-r: 217;
--grey-light-1-g: 217;
--grey-light-1-b: 217;
--grey-light-1-contrast: black;
--grey-light-1-contrast-darker: black;
--grey-light-1-text-color: var(--body-color);
--grey-light-2: #eeeeee;
--grey-light-2-darker: #d6d6d6;
--grey-light-2-r: 238;
--grey-light-2-g: 238;
--grey-light-2-b: 238;
--grey-light-2-contrast: black;
--grey-light-2-contrast-darker: black;
--grey-light-2-text-color: var(--body-color);
--grey-light-3: #f6f6f6;
--grey-light-3-darker: #dddddd;
--grey-light-3-r: 246;
--grey-light-3-g: 246;
--grey-light-3-b: 246;
--grey-light-3-contrast: black;
--grey-light-3-contrast-darker: black;
--grey-light-3-text-color: var(--body-color);
--color-1-base: #7da2a9;
--color-1-base-darker: #6b959d;
--color-1-base-r: 125;
--color-1-base-g: 162;
--color-1-base-b: 169;
--color-1-base-contrast: white;
--color-1-base-contrast-darker: white;
--color-1-base-text-color: var(--body-alt-color);
--color-1-dark-3: #293133;
--color-1-dark-3-darker: #252c2e;
--color-1-dark-3-r: 41;
--color-1-dark-3-g: 49;
--color-1-dark-3-b: 51;
--color-1-dark-3-contrast: white;
--color-1-dark-3-contrast-darker: white;
--color-1-dark-3-text-color: var(--body-alt-color);
--color-1-dark-2: #46575a;
--color-1-dark-2-darker: #3f4e51;
--color-1-dark-2-r: 70;
--color-1-dark-2-g: 87;
--color-1-dark-2-b: 90;
--color-1-dark-2-contrast: white;
--color-1-dark-2-contrast-darker: white;
--color-1-dark-2-text-color: var(--body-alt-color);
--color-1-dark-1: #637d82;
--color-1-dark-1-darker: #597075;
--color-1-dark-1-r: 99;
--color-1-dark-1-g: 125;
--color-1-dark-1-b: 130;
--color-1-dark-1-contrast: white;
--color-1-dark-1-contrast-darker: white;
--color-1-dark-1-text-color: var(--body-alt-color);
--color-1: #7da2a9;
--color-1-darker: #6b959d;
--color-1-r: 125;
--color-1-g: 162;
--color-1-b: 169;
--color-1-contrast: white;
--color-1-contrast-darker: white;
--color-1-text-color: var(--body-alt-color);
--color-1-light-1: #9fbdc3;
--color-1-light-1-darker: #89aeb5;
--color-1-light-1-r: 159;
--color-1-light-1-g: 189;
--color-1-light-1-b: 195;
--color-1-light-1-contrast: white;
--color-1-light-1-contrast-darker: white;
--color-1-light-1-text-color: var(--body-alt-color);
--color-1-light-2: #c6d9dd;
--color-1-light-2-darker: #acc8cd;
--color-1-light-2-r: 198;
--color-1-light-2-g: 217;
--color-1-light-2-b: 221;
--color-1-light-2-contrast: black;
--color-1-light-2-contrast-darker: black;
--color-1-light-2-text-color: var(--body-color);
--color-1-light-3: #f0f5f6;
--color-1-light-3-darker: #d2e1e4;
--color-1-light-3-r: 240;
--color-1-light-3-g: 245;
--color-1-light-3-b: 246;
--color-1-light-3-contrast: black;
--color-1-light-3-contrast-darker: black;
--color-1-light-3-text-color: var(--body-color);
--color-2-base: #4c637f;
--color-2-base-darker: #445972;
--color-2-base-r: 76;
--color-2-base-g: 99;
--color-2-base-b: 127;
--color-2-base-contrast: white;
--color-2-base-contrast-darker: white;
--color-2-base-text-color: var(--body-alt-color);
--color-2-dark-3: #292d33;
--color-2-dark-3-darker: #25292e;
--color-2-dark-3-r: 41;
--color-2-dark-3-g: 45;
--color-2-dark-3-b: 51;
--color-2-dark-3-contrast: white;
--color-2-dark-3-contrast-darker: white;
--color-2-dark-3-text-color: var(--body-alt-color);
--color-2-dark-2: #3e4a59;
--color-2-dark-2-darker: #384350;
--color-2-dark-2-r: 62;
--color-2-dark-2-g: 74;
--color-2-dark-2-b: 89;
--color-2-dark-2-contrast: white;
--color-2-dark-2-contrast-darker: white;
--color-2-dark-2-text-color: var(--body-alt-color);
--color-2-dark-1: #4c637f;
--color-2-dark-1-darker: #445972;
--color-2-dark-1-r: 76;
--color-2-dark-1-g: 99;
--color-2-dark-1-b: 127;
--color-2-dark-1-contrast: white;
--color-2-dark-1-contrast-darker: white;
--color-2-dark-1-text-color: var(--body-alt-color);
--color-2: #85a0c1;
--color-2-darker: #6f8fb6;
--color-2-r: 133;
--color-2-g: 160;
--color-2-b: 193;
--color-2-contrast: white;
--color-2-contrast-darker: white;
--color-2-text-color: var(--body-alt-color);
--color-2-light-1: #a6bbd4;
--color-2-light-1-darker: #8da8c8;
--color-2-light-1-r: 166;
--color-2-light-1-g: 187;
--color-2-light-1-b: 212;
--color-2-light-1-contrast: white;
--color-2-light-1-contrast-darker: white;
--color-2-light-1-text-color: var(--body-alt-color);
--color-2-light-2: #cad7e6;
--color-2-light-2-darker: #adc1d8;
--color-2-light-2-r: 202;
--color-2-light-2-g: 215;
--color-2-light-2-b: 230;
--color-2-light-2-contrast: black;
--color-2-light-2-contrast-darker: black;
--color-2-light-2-text-color: var(--body-color);
--color-2-light-3: #f1f5f9;
--color-2-light-3-darker: #cfddea;
--color-2-light-3-r: 241;
--color-2-light-3-g: 245;
--color-2-light-3-b: 249;
--color-2-light-3-contrast: black;
--color-2-light-3-contrast-darker: black;
--color-2-light-3-text-color: var(--body-color);
--color-3-base: #18181e;
--color-3-base-darker: #16161b;
--color-3-base-r: 24;
--color-3-base-g: 24;
--color-3-base-b: 30;
--color-3-base-contrast: white;
--color-3-base-contrast-darker: white;
--color-3-base-text-color: var(--body-alt-color);
--color-3-dark-3: #292933;
--color-3-dark-3-darker: #25252e;
--color-3-dark-3-r: 41;
--color-3-dark-3-g: 41;
--color-3-dark-3-b: 51;
--color-3-dark-3-contrast: white;
--color-3-dark-3-contrast-darker: white;
--color-3-dark-3-text-color: var(--body-alt-color);
--color-3-dark-2: #41414c;
--color-3-dark-2-darker: #3b3b44;
--color-3-dark-2-r: 65;
--color-3-dark-2-g: 65;
--color-3-dark-2-b: 76;
--color-3-dark-2-contrast: white;
--color-3-dark-2-contrast-darker: white;
--color-3-dark-2-text-color: var(--body-alt-color);
--color-3-dark-1: #6f6f7b;
--color-3-dark-1-darker: #64646f;
--color-3-dark-1-r: 111;
--color-3-dark-1-g: 111;
--color-3-dark-1-b: 123;
--color-3-dark-1-contrast: white;
--color-3-dark-1-contrast-darker: white;
--color-3-dark-1-text-color: var(--body-alt-color);
--color-3: #a3a3a9;
--color-3-darker: #929299;
--color-3-r: 163;
--color-3-g: 163;
--color-3-b: 169;
--color-3-contrast: white;
--color-3-contrast-darker: white;
--color-3-text-color: var(--body-alt-color);
--color-3-light-1: #bebec3;
--color-3-light-1-darker: #aaaab1;
--color-3-light-1-r: 190;
--color-3-light-1-g: 190;
--color-3-light-1-b: 195;
--color-3-light-1-contrast: black;
--color-3-light-1-contrast-darker: white;
--color-3-light-1-text-color: var(--body-color);
--color-3-light-2: #d9d9dd;
--color-3-light-2-darker: #c2c2c8;
--color-3-light-2-r: 217;
--color-3-light-2-g: 217;
--color-3-light-2-b: 221;
--color-3-light-2-contrast: black;
--color-3-light-2-contrast-darker: black;
--color-3-light-2-text-color: var(--body-color);
--color-3-light-3: #f5f5f6;
--color-3-light-3-darker: #dbdbdf;
--color-3-light-3-r: 245;
--color-3-light-3-g: 245;
--color-3-light-3-b: 246;
--color-3-light-3-contrast: black;
--color-3-light-3-contrast-darker: black;
--color-3-light-3-text-color: var(--body-color);
--color-4-base: #92e4fd;
--color-4-base-darker: #6bdafc;
--color-4-base-r: 146;
--color-4-base-g: 228;
--color-4-base-b: 253;
--color-4-base-contrast: black;
--color-4-base-contrast-darker: black;
--color-4-base-text-color: var(--body-color);
--color-4-dark-3: #293133;
--color-4-dark-3-darker: #252c2e;
--color-4-dark-3-r: 41;
--color-4-dark-3-g: 49;
--color-4-dark-3-b: 51;
--color-4-dark-3-contrast: white;
--color-4-dark-3-contrast-darker: white;
--color-4-dark-3-text-color: var(--body-alt-color);
--color-4-dark-2: #496168;
--color-4-dark-2-darker: #42575e;
--color-4-dark-2-r: 73;
--color-4-dark-2-g: 97;
--color-4-dark-2-b: 104;
--color-4-dark-2-contrast: white;
--color-4-dark-2-contrast-darker: white;
--color-4-dark-2-text-color: var(--body-alt-color);
--color-4-dark-1: #5f8e9c;
--color-4-dark-1-darker: #56808c;
--color-4-dark-1-r: 95;
--color-4-dark-1-g: 142;
--color-4-dark-1-b: 156;
--color-4-dark-1-contrast: white;
--color-4-dark-1-contrast-darker: white;
--color-4-dark-1-text-color: var(--body-alt-color);
--color-4: #6cb9d1;
--color-4-darker: #54aec9;
--color-4-r: 108;
--color-4-g: 185;
--color-4-b: 209;
--color-4-contrast: white;
--color-4-contrast-darker: white;
--color-4-text-color: var(--body-alt-color);
--color-4-light-1: #92e4fd;
--color-4-light-1-darker: #6bdafc;
--color-4-light-1-r: 146;
--color-4-light-1-g: 228;
--color-4-light-1-b: 253;
--color-4-light-1-contrast: black;
--color-4-light-1-contrast-darker: black;
--color-4-light-1-text-color: var(--body-color);
--color-4-light-2: #c3f0fe;
--color-4-light-2-darker: #97e5fd;
--color-4-light-2-r: 195;
--color-4-light-2-g: 240;
--color-4-light-2-b: 254;
--color-4-light-2-contrast: black;
--color-4-light-2-contrast-darker: black;
--color-4-light-2-text-color: var(--body-color);
--color-4-light-3: #f4fcff;
--color-4-light-3-darker: #c2eeff;
--color-4-light-3-r: 244;
--color-4-light-3-g: 252;
--color-4-light-3-b: 255;
--color-4-light-3-contrast: black;
--color-4-light-3-contrast-darker: black;
--color-4-light-3-text-color: var(--body-color);
--color-5-base: #b8c1cc;
--color-5-base-darker: #a1adbc;
--color-5-base-r: 184;
--color-5-base-g: 193;
--color-5-base-b: 204;
--color-5-base-contrast: black;
--color-5-base-contrast-darker: white;
--color-5-base-text-color: var(--body-color);
--color-5-dark-3: #292d33;
--color-5-dark-3-darker: #25292e;
--color-5-dark-3-r: 41;
--color-5-dark-3-g: 45;
--color-5-dark-3-b: 51;
--color-5-dark-3-contrast: white;
--color-5-dark-3-contrast-darker: white;
--color-5-dark-3-text-color: var(--body-alt-color);
--color-5-dark-2: #555d66;
--color-5-dark-2-darker: #4d545c;
--color-5-dark-2-r: 85;
--color-5-dark-2-g: 93;
--color-5-dark-2-b: 102;
--color-5-dark-2-contrast: white;
--color-5-dark-2-contrast-darker: white;
--color-5-dark-2-text-color: var(--body-alt-color);
--color-5-dark-1: #858e99;
--color-5-dark-1-darker: #75808c;
--color-5-dark-1-r: 133;
--color-5-dark-1-g: 142;
--color-5-dark-1-b: 153;
--color-5-dark-1-contrast: white;
--color-5-dark-1-contrast-darker: white;
--color-5-dark-1-text-color: var(--body-alt-color);
--color-5: #b8c1cc;
--color-5-darker: #a1adbc;
--color-5-r: 184;
--color-5-g: 193;
--color-5-b: 204;
--color-5-contrast: black;
--color-5-contrast-darker: white;
--color-5-text-color: var(--body-color);
--color-5-light-1: #ccd3db;
--color-5-light-1-darker: #b3bec9;
--color-5-light-1-r: 204;
--color-5-light-1-g: 211;
--color-5-light-1-b: 219;
--color-5-light-1-contrast: black;
--color-5-light-1-contrast-darker: black;
--color-5-light-1-text-color: var(--body-color);
--color-5-light-2: #e0e5eb;
--color-5-light-2-darker: #c4ced9;
--color-5-light-2-r: 224;
--color-5-light-2-g: 229;
--color-5-light-2-b: 235;
--color-5-light-2-contrast: black;
--color-5-light-2-contrast-darker: black;
--color-5-light-2-text-color: var(--body-color);
--color-5-light-3: #f5f7fa;
--color-5-light-3-darker: #d4dde9;
--color-5-light-3-r: 245;
--color-5-light-3-g: 247;
--color-5-light-3-b: 250;
--color-5-light-3-contrast: black;
--color-5-light-3-contrast-darker: black;
--color-5-light-3-text-color: var(--body-color);
--white-contrast: var(--body-color);
--shading-contrast: var(--body-alt-color);
--bg-contrast: var(--body-color);
}.u-custom-color-1,
        .u-body.u-custom-color-1,
        .u-container-style.u-custom-color-1:before,
        .u-container-layout.u-custom-color-1:before,
        .u-table-alt-custom-color-1 tr:nth-child(even)
        {
            color: var(--custom-color-1-text-color);
            background-color: var(--custom-color-1);
        }

        .u-button-style.u-custom-color-1,
        .u-button-style.u-custom-color-1[class*="u-border-"]
        {
            color: var(--custom-color-1-text-color) !important;
            background-color: var(--custom-color-1) !important;
        }

        .u-button-style.u-custom-color-1:hover,
        .u-button-style.u-custom-color-1[class*="u-border-"]:hover,
        .u-button-style.u-custom-color-1:focus,
        .u-button-style.u-custom-color-1[class*="u-border-"]:focus,
        .u-button-style.u-button-style.u-custom-color-1:active,
        .u-button-style.u-button-style.u-custom-color-1[class*="u-border-"]:active,
        .u-button-style.u-button-style.u-custom-color-1.active,
        .u-button-style.u-button-style.u-custom-color-1[class*="u-border-"].active,
        li.active > .u-button-style.u-button-style.u-custom-color-1,
        li.active > .u-button-style.u-button-style.u-custom-color-1[class*="u-border-"]
        {
            color: var(--custom-color-1-text-color) !important;
            background-color: var(--custom-color-1-darker) !important;
        }

        .u-hover-custom-color-1:hover,
        .u-hover-custom-color-1[class*="u-border-"]:hover,
        .u-hover-custom-color-1:focus,
        .u-hover-custom-color-1[class*="u-border-"]:focus,
        .u-active-custom-color-1.u-active.u-active,
        .u-active-custom-color-1[class*="u-border-"].u-active.u-active,
        a.u-button-style.u-hover-custom-color-1:hover,
        a.u-button-style.u-hover-custom-color-1[class*="u-border-"]:hover,
        a.u-button-style:hover > .u-hover-custom-color-1,
        a.u-button-style:hover > .u-hover-custom-color-1[class*="u-border-"],
        a.u-button-style.u-hover-custom-color-1:focus,
        a.u-button-style.u-hover-custom-color-1[class*="u-border-"]:focus,
        a.u-button-style.u-button-style.u-active-custom-color-1:active,
        a.u-button-style.u-button-style.u-active-custom-color-1[class*="u-border-"]:active,
        a.u-button-style.u-button-style.u-active-custom-color-1.active,
        a.u-button-style.u-button-style.u-active-custom-color-1[class*="u-border-"].active,
        a.u-button-style.u-button-style.active > .u-active-custom-color-1,
        a.u-button-style.u-button-style.active > .u-active-custom-color-1[class*="u-border-"],
        li.active > a.u-button-style.u-button-style.u-active-custom-color-1,
        li.active > a.u-button-style.u-button-style.u-active-custom-color-1[class*="u-border-"]
        {
            color: var(--custom-color-1-text-color) !important;
            background-color: var(--custom-color-1) !important;
        }

        a.u-link.u-hover-custom-color-1:hover {
            color: var(--custom-color-1) !important;
        }

        
        
        .u-custom-color-2,
        .u-body.u-custom-color-2,
        .u-container-style.u-custom-color-2:before,
        .u-container-layout.u-custom-color-2:before,
        .u-table-alt-custom-color-2 tr:nth-child(even)
        {
            color: var(--custom-color-2-text-color);
            background-color: var(--custom-color-2);
        }

        .u-button-style.u-custom-color-2,
        .u-button-style.u-custom-color-2[class*="u-border-"]
        {
            color: var(--custom-color-2-text-color) !important;
            background-color: var(--custom-color-2) !important;
        }

        .u-button-style.u-custom-color-2:hover,
        .u-button-style.u-custom-color-2[class*="u-border-"]:hover,
        .u-button-style.u-custom-color-2:focus,
        .u-button-style.u-custom-color-2[class*="u-border-"]:focus,
        .u-button-style.u-button-style.u-custom-color-2:active,
        .u-button-style.u-button-style.u-custom-color-2[class*="u-border-"]:active,
        .u-button-style.u-button-style.u-custom-color-2.active,
        .u-button-style.u-button-style.u-custom-color-2[class*="u-border-"].active,
        li.active > .u-button-style.u-button-style.u-custom-color-2,
        li.active > .u-button-style.u-button-style.u-custom-color-2[class*="u-border-"]
        {
            color: var(--custom-color-2-text-color) !important;
            background-color: var(--custom-color-2-darker) !important;
        }

        .u-hover-custom-color-2:hover,
        .u-hover-custom-color-2[class*="u-border-"]:hover,
        .u-hover-custom-color-2:focus,
        .u-hover-custom-color-2[class*="u-border-"]:focus,
        .u-active-custom-color-2.u-active.u-active,
        .u-active-custom-color-2[class*="u-border-"].u-active.u-active,
        a.u-button-style.u-hover-custom-color-2:hover,
        a.u-button-style.u-hover-custom-color-2[class*="u-border-"]:hover,
        a.u-button-style:hover > .u-hover-custom-color-2,
        a.u-button-style:hover > .u-hover-custom-color-2[class*="u-border-"],
        a.u-button-style.u-hover-custom-color-2:focus,
        a.u-button-style.u-hover-custom-color-2[class*="u-border-"]:focus,
        a.u-button-style.u-button-style.u-active-custom-color-2:active,
        a.u-button-style.u-button-style.u-active-custom-color-2[class*="u-border-"]:active,
        a.u-button-style.u-button-style.u-active-custom-color-2.active,
        a.u-button-style.u-button-style.u-active-custom-color-2[class*="u-border-"].active,
        a.u-button-style.u-button-style.active > .u-active-custom-color-2,
        a.u-button-style.u-button-style.active > .u-active-custom-color-2[class*="u-border-"],
        li.active > a.u-button-style.u-button-style.u-active-custom-color-2,
        li.active > a.u-button-style.u-button-style.u-active-custom-color-2[class*="u-border-"]
        {
            color: var(--custom-color-2-text-color) !important;
            background-color: var(--custom-color-2) !important;
        }

        a.u-link.u-hover-custom-color-2:hover {
            color: var(--custom-color-2) !important;
        }

        
        
        .u-custom-color-3,
        .u-body.u-custom-color-3,
        .u-container-style.u-custom-color-3:before,
        .u-container-layout.u-custom-color-3:before,
        .u-table-alt-custom-color-3 tr:nth-child(even)
        {
            color: var(--custom-color-3-text-color);
            background-color: var(--custom-color-3);
        }

        .u-button-style.u-custom-color-3,
        .u-button-style.u-custom-color-3[class*="u-border-"]
        {
            color: var(--custom-color-3-text-color) !important;
            background-color: var(--custom-color-3) !important;
        }

        .u-button-style.u-custom-color-3:hover,
        .u-button-style.u-custom-color-3[class*="u-border-"]:hover,
        .u-button-style.u-custom-color-3:focus,
        .u-button-style.u-custom-color-3[class*="u-border-"]:focus,
        .u-button-style.u-button-style.u-custom-color-3:active,
        .u-button-style.u-button-style.u-custom-color-3[class*="u-border-"]:active,
        .u-button-style.u-button-style.u-custom-color-3.active,
        .u-button-style.u-button-style.u-custom-color-3[class*="u-border-"].active,
        li.active > .u-button-style.u-button-style.u-custom-color-3,
        li.active > .u-button-style.u-button-style.u-custom-color-3[class*="u-border-"]
        {
            color: var(--custom-color-3-text-color) !important;
            background-color: var(--custom-color-3-darker) !important;
        }

        .u-hover-custom-color-3:hover,
        .u-hover-custom-color-3[class*="u-border-"]:hover,
        .u-hover-custom-color-3:focus,
        .u-hover-custom-color-3[class*="u-border-"]:focus,
        .u-active-custom-color-3.u-active.u-active,
        .u-active-custom-color-3[class*="u-border-"].u-active.u-active,
        a.u-button-style.u-hover-custom-color-3:hover,
        a.u-button-style.u-hover-custom-color-3[class*="u-border-"]:hover,
        a.u-button-style:hover > .u-hover-custom-color-3,
        a.u-button-style:hover > .u-hover-custom-color-3[class*="u-border-"],
        a.u-button-style.u-hover-custom-color-3:focus,
        a.u-button-style.u-hover-custom-color-3[class*="u-border-"]:focus,
        a.u-button-style.u-button-style.u-active-custom-color-3:active,
        a.u-button-style.u-button-style.u-active-custom-color-3[class*="u-border-"]:active,
        a.u-button-style.u-button-style.u-active-custom-color-3.active,
        a.u-button-style.u-button-style.u-active-custom-color-3[class*="u-border-"].active,
        a.u-button-style.u-button-style.active > .u-active-custom-color-3,
        a.u-button-style.u-button-style.active > .u-active-custom-color-3[class*="u-border-"],
        li.active > a.u-button-style.u-button-style.u-active-custom-color-3,
        li.active > a.u-button-style.u-button-style.u-active-custom-color-3[class*="u-border-"]
        {
            color: var(--custom-color-3-text-color) !important;
            background-color: var(--custom-color-3) !important;
        }

        a.u-link.u-hover-custom-color-3:hover {
            color: var(--custom-color-3) !important;
        }

        
        
        .u-custom-color-4,
        .u-body.u-custom-color-4,
        .u-container-style.u-custom-color-4:before,
        .u-container-layout.u-custom-color-4:before,
        .u-table-alt-custom-color-4 tr:nth-child(even)
        {
            color: var(--custom-color-4-text-color);
            background-color: var(--custom-color-4);
        }

        .u-button-style.u-custom-color-4,
        .u-button-style.u-custom-color-4[class*="u-border-"]
        {
            color: var(--custom-color-4-text-color) !important;
            background-color: var(--custom-color-4) !important;
        }

        .u-button-style.u-custom-color-4:hover,
        .u-button-style.u-custom-color-4[class*="u-border-"]:hover,
        .u-button-style.u-custom-color-4:focus,
        .u-button-style.u-custom-color-4[class*="u-border-"]:focus,
        .u-button-style.u-button-style.u-custom-color-4:active,
        .u-button-style.u-button-style.u-custom-color-4[class*="u-border-"]:active,
        .u-button-style.u-button-style.u-custom-color-4.active,
        .u-button-style.u-button-style.u-custom-color-4[class*="u-border-"].active,
        li.active > .u-button-style.u-button-style.u-custom-color-4,
        li.active > .u-button-style.u-button-style.u-custom-color-4[class*="u-border-"]
        {
            color: var(--custom-color-4-text-color) !important;
            background-color: var(--custom-color-4-darker) !important;
        }

        .u-hover-custom-color-4:hover,
        .u-hover-custom-color-4[class*="u-border-"]:hover,
        .u-hover-custom-color-4:focus,
        .u-hover-custom-color-4[class*="u-border-"]:focus,
        .u-active-custom-color-4.u-active.u-active,
        .u-active-custom-color-4[class*="u-border-"].u-active.u-active,
        a.u-button-style.u-hover-custom-color-4:hover,
        a.u-button-style.u-hover-custom-color-4[class*="u-border-"]:hover,
        a.u-button-style:hover > .u-hover-custom-color-4,
        a.u-button-style:hover > .u-hover-custom-color-4[class*="u-border-"],
        a.u-button-style.u-hover-custom-color-4:focus,
        a.u-button-style.u-hover-custom-color-4[class*="u-border-"]:focus,
        a.u-button-style.u-button-style.u-active-custom-color-4:active,
        a.u-button-style.u-button-style.u-active-custom-color-4[class*="u-border-"]:active,
        a.u-button-style.u-button-style.u-active-custom-color-4.active,
        a.u-button-style.u-button-style.u-active-custom-color-4[class*="u-border-"].active,
        a.u-button-style.u-button-style.active > .u-active-custom-color-4,
        a.u-button-style.u-button-style.active > .u-active-custom-color-4[class*="u-border-"],
        li.active > a.u-button-style.u-button-style.u-active-custom-color-4,
        li.active > a.u-button-style.u-button-style.u-active-custom-color-4[class*="u-border-"]
        {
            color: var(--custom-color-4-text-color) !important;
            background-color: var(--custom-color-4) !important;
        }

        a.u-link.u-hover-custom-color-4:hover {
            color: var(--custom-color-4) !important;
        }

        
        
        .u-custom-color-5,
        .u-body.u-custom-color-5,
        .u-container-style.u-custom-color-5:before,
        .u-container-layout.u-custom-color-5:before,
        .u-table-alt-custom-color-5 tr:nth-child(even)
        {
            color: var(--custom-color-5-text-color);
            background-color: var(--custom-color-5);
        }

        .u-button-style.u-custom-color-5,
        .u-button-style.u-custom-color-5[class*="u-border-"]
        {
            color: var(--custom-color-5-text-color) !important;
            background-color: var(--custom-color-5) !important;
        }

        .u-button-style.u-custom-color-5:hover,
        .u-button-style.u-custom-color-5[class*="u-border-"]:hover,
        .u-button-style.u-custom-color-5:focus,
        .u-button-style.u-custom-color-5[class*="u-border-"]:focus,
        .u-button-style.u-button-style.u-custom-color-5:active,
        .u-button-style.u-button-style.u-custom-color-5[class*="u-border-"]:active,
        .u-button-style.u-button-style.u-custom-color-5.active,
        .u-button-style.u-button-style.u-custom-color-5[class*="u-border-"].active,
        li.active > .u-button-style.u-button-style.u-custom-color-5,
        li.active > .u-button-style.u-button-style.u-custom-color-5[class*="u-border-"]
        {
            color: var(--custom-color-5-text-color) !important;
            background-color: var(--custom-color-5-darker) !important;
        }

        .u-hover-custom-color-5:hover,
        .u-hover-custom-color-5[class*="u-border-"]:hover,
        .u-hover-custom-color-5:focus,
        .u-hover-custom-color-5[class*="u-border-"]:focus,
        .u-active-custom-color-5.u-active.u-active,
        .u-active-custom-color-5[class*="u-border-"].u-active.u-active,
        a.u-button-style.u-hover-custom-color-5:hover,
        a.u-button-style.u-hover-custom-color-5[class*="u-border-"]:hover,
        a.u-button-style:hover > .u-hover-custom-color-5,
        a.u-button-style:hover > .u-hover-custom-color-5[class*="u-border-"],
        a.u-button-style.u-hover-custom-color-5:focus,
        a.u-button-style.u-hover-custom-color-5[class*="u-border-"]:focus,
        a.u-button-style.u-button-style.u-active-custom-color-5:active,
        a.u-button-style.u-button-style.u-active-custom-color-5[class*="u-border-"]:active,
        a.u-button-style.u-button-style.u-active-custom-color-5.active,
        a.u-button-style.u-button-style.u-active-custom-color-5[class*="u-border-"].active,
        a.u-button-style.u-button-style.active > .u-active-custom-color-5,
        a.u-button-style.u-button-style.active > .u-active-custom-color-5[class*="u-border-"],
        li.active > a.u-button-style.u-button-style.u-active-custom-color-5,
        li.active > a.u-button-style.u-button-style.u-active-custom-color-5[class*="u-border-"]
        {
            color: var(--custom-color-5-text-color) !important;
            background-color: var(--custom-color-5) !important;
        }

        a.u-link.u-hover-custom-color-5:hover {
            color: var(--custom-color-5) !important;
        }

        
        
        .u-custom-color-6,
        .u-body.u-custom-color-6,
        .u-container-style.u-custom-color-6:before,
        .u-container-layout.u-custom-color-6:before,
        .u-table-alt-custom-color-6 tr:nth-child(even)
        {
            color: var(--custom-color-6-text-color);
            background-color: var(--custom-color-6);
        }

        .u-button-style.u-custom-color-6,
        .u-button-style.u-custom-color-6[class*="u-border-"]
        {
            color: var(--custom-color-6-text-color) !important;
            background-color: var(--custom-color-6) !important;
        }

        .u-button-style.u-custom-color-6:hover,
        .u-button-style.u-custom-color-6[class*="u-border-"]:hover,
        .u-button-style.u-custom-color-6:focus,
        .u-button-style.u-custom-color-6[class*="u-border-"]:focus,
        .u-button-style.u-button-style.u-custom-color-6:active,
        .u-button-style.u-button-style.u-custom-color-6[class*="u-border-"]:active,
        .u-button-style.u-button-style.u-custom-color-6.active,
        .u-button-style.u-button-style.u-custom-color-6[class*="u-border-"].active,
        li.active > .u-button-style.u-button-style.u-custom-color-6,
        li.active > .u-button-style.u-button-style.u-custom-color-6[class*="u-border-"]
        {
            color: var(--custom-color-6-text-color) !important;
            background-color: var(--custom-color-6-darker) !important;
        }

        .u-hover-custom-color-6:hover,
        .u-hover-custom-color-6[class*="u-border-"]:hover,
        .u-hover-custom-color-6:focus,
        .u-hover-custom-color-6[class*="u-border-"]:focus,
        .u-active-custom-color-6.u-active.u-active,
        .u-active-custom-color-6[class*="u-border-"].u-active.u-active,
        a.u-button-style.u-hover-custom-color-6:hover,
        a.u-button-style.u-hover-custom-color-6[class*="u-border-"]:hover,
        a.u-button-style:hover > .u-hover-custom-color-6,
        a.u-button-style:hover > .u-hover-custom-color-6[class*="u-border-"],
        a.u-button-style.u-hover-custom-color-6:focus,
        a.u-button-style.u-hover-custom-color-6[class*="u-border-"]:focus,
        a.u-button-style.u-button-style.u-active-custom-color-6:active,
        a.u-button-style.u-button-style.u-active-custom-color-6[class*="u-border-"]:active,
        a.u-button-style.u-button-style.u-active-custom-color-6.active,
        a.u-button-style.u-button-style.u-active-custom-color-6[class*="u-border-"].active,
        a.u-button-style.u-button-style.active > .u-active-custom-color-6,
        a.u-button-style.u-button-style.active > .u-active-custom-color-6[class*="u-border-"],
        li.active > a.u-button-style.u-button-style.u-active-custom-color-6,
        li.active > a.u-button-style.u-button-style.u-active-custom-color-6[class*="u-border-"]
        {
            color: var(--custom-color-6-text-color) !important;
            background-color: var(--custom-color-6) !important;
        }

        a.u-link.u-hover-custom-color-6:hover {
            color: var(--custom-color-6) !important;
        }

        

        
        .u-border-custom-color-1,
        .u-separator-custom-color-1:after
        {
            border-color: var(--custom-color-1);
            stroke: var(--custom-color-1);
        }

        .u-button-style.u-border-custom-color-1
        {
            border-color: var(--custom-color-1) !important;
            color: var(--custom-color-1) !important;
            background-color: transparent !important;
        }

        .u-button-style.u-border-custom-color-1:hover,
        .u-button-style.u-border-custom-color-1:focus
        {
            border-color: transparent !important;
            color: var(--custom-color-1-darker) !important;
            background-color: transparent !important;
        }

        .u-border-hover-custom-color-1:hover,
        .u-border-hover-custom-color-1:focus,
        .u-border-active-custom-color-1.u-active.u-active,
        a.u-button-style.u-border-hover-custom-color-1:hover,
        a.u-button-style:hover > .u-border-hover-custom-color-1,
        a.u-button-style.u-border-hover-custom-color-1:focus,
        a.u-button-style.u-button-style.u-border-active-custom-color-1:active,
        a.u-button-style.u-button-style.u-border-active-custom-color-1.active,
        a.u-button-style.u-button-style.active > .u-border-active-custom-color-1,
        li.active > a.u-button-style.u-button-style.u-border-active-custom-color-1
        {
            color: var(--custom-color-1) !important;
            border-color: var(--custom-color-1) !important;
        }

        .u-link.u-border-custom-color-1[class*="u-border-"]
        {
            border-color: var(--custom-color-1) !important;
        }

        .u-link.u-border-custom-color-1[class*="u-border-"]:hover
        {
            border-color: var(--custom-color-1-darker) !important;
        }
        
        
        .u-border-custom-color-2,
        .u-separator-custom-color-2:after
        {
            border-color: var(--custom-color-2);
            stroke: var(--custom-color-2);
        }

        .u-button-style.u-border-custom-color-2
        {
            border-color: var(--custom-color-2) !important;
            color: var(--custom-color-2) !important;
            background-color: transparent !important;
        }

        .u-button-style.u-border-custom-color-2:hover,
        .u-button-style.u-border-custom-color-2:focus
        {
            border-color: transparent !important;
            color: var(--custom-color-2-darker) !important;
            background-color: transparent !important;
        }

        .u-border-hover-custom-color-2:hover,
        .u-border-hover-custom-color-2:focus,
        .u-border-active-custom-color-2.u-active.u-active,
        a.u-button-style.u-border-hover-custom-color-2:hover,
        a.u-button-style:hover > .u-border-hover-custom-color-2,
        a.u-button-style.u-border-hover-custom-color-2:focus,
        a.u-button-style.u-button-style.u-border-active-custom-color-2:active,
        a.u-button-style.u-button-style.u-border-active-custom-color-2.active,
        a.u-button-style.u-button-style.active > .u-border-active-custom-color-2,
        li.active > a.u-button-style.u-button-style.u-border-active-custom-color-2
        {
            color: var(--custom-color-2) !important;
            border-color: var(--custom-color-2) !important;
        }

        .u-link.u-border-custom-color-2[class*="u-border-"]
        {
            border-color: var(--custom-color-2) !important;
        }

        .u-link.u-border-custom-color-2[class*="u-border-"]:hover
        {
            border-color: var(--custom-color-2-darker) !important;
        }
        
        
        .u-border-custom-color-3,
        .u-separator-custom-color-3:after
        {
            border-color: var(--custom-color-3);
            stroke: var(--custom-color-3);
        }

        .u-button-style.u-border-custom-color-3
        {
            border-color: var(--custom-color-3) !important;
            color: var(--custom-color-3) !important;
            background-color: transparent !important;
        }

        .u-button-style.u-border-custom-color-3:hover,
        .u-button-style.u-border-custom-color-3:focus
        {
            border-color: transparent !important;
            color: var(--custom-color-3-darker) !important;
            background-color: transparent !important;
        }

        .u-border-hover-custom-color-3:hover,
        .u-border-hover-custom-color-3:focus,
        .u-border-active-custom-color-3.u-active.u-active,
        a.u-button-style.u-border-hover-custom-color-3:hover,
        a.u-button-style:hover > .u-border-hover-custom-color-3,
        a.u-button-style.u-border-hover-custom-color-3:focus,
        a.u-button-style.u-button-style.u-border-active-custom-color-3:active,
        a.u-button-style.u-button-style.u-border-active-custom-color-3.active,
        a.u-button-style.u-button-style.active > .u-border-active-custom-color-3,
        li.active > a.u-button-style.u-button-style.u-border-active-custom-color-3
        {
            color: var(--custom-color-3) !important;
            border-color: var(--custom-color-3) !important;
        }

        .u-link.u-border-custom-color-3[class*="u-border-"]
        {
            border-color: var(--custom-color-3) !important;
        }

        .u-link.u-border-custom-color-3[class*="u-border-"]:hover
        {
            border-color: var(--custom-color-3-darker) !important;
        }
        
        
        .u-border-custom-color-4,
        .u-separator-custom-color-4:after
        {
            border-color: var(--custom-color-4);
            stroke: var(--custom-color-4);
        }

        .u-button-style.u-border-custom-color-4
        {
            border-color: var(--custom-color-4) !important;
            color: var(--custom-color-4) !important;
            background-color: transparent !important;
        }

        .u-button-style.u-border-custom-color-4:hover,
        .u-button-style.u-border-custom-color-4:focus
        {
            border-color: transparent !important;
            color: var(--custom-color-4-darker) !important;
            background-color: transparent !important;
        }

        .u-border-hover-custom-color-4:hover,
        .u-border-hover-custom-color-4:focus,
        .u-border-active-custom-color-4.u-active.u-active,
        a.u-button-style.u-border-hover-custom-color-4:hover,
        a.u-button-style:hover > .u-border-hover-custom-color-4,
        a.u-button-style.u-border-hover-custom-color-4:focus,
        a.u-button-style.u-button-style.u-border-active-custom-color-4:active,
        a.u-button-style.u-button-style.u-border-active-custom-color-4.active,
        a.u-button-style.u-button-style.active > .u-border-active-custom-color-4,
        li.active > a.u-button-style.u-button-style.u-border-active-custom-color-4
        {
            color: var(--custom-color-4) !important;
            border-color: var(--custom-color-4) !important;
        }

        .u-link.u-border-custom-color-4[class*="u-border-"]
        {
            border-color: var(--custom-color-4) !important;
        }

        .u-link.u-border-custom-color-4[class*="u-border-"]:hover
        {
            border-color: var(--custom-color-4-darker) !important;
        }
        
        
        .u-border-custom-color-5,
        .u-separator-custom-color-5:after
        {
            border-color: var(--custom-color-5);
            stroke: var(--custom-color-5);
        }

        .u-button-style.u-border-custom-color-5
        {
            border-color: var(--custom-color-5) !important;
            color: var(--custom-color-5) !important;
            background-color: transparent !important;
        }

        .u-button-style.u-border-custom-color-5:hover,
        .u-button-style.u-border-custom-color-5:focus
        {
            border-color: transparent !important;
            color: var(--custom-color-5-darker) !important;
            background-color: transparent !important;
        }

        .u-border-hover-custom-color-5:hover,
        .u-border-hover-custom-color-5:focus,
        .u-border-active-custom-color-5.u-active.u-active,
        a.u-button-style.u-border-hover-custom-color-5:hover,
        a.u-button-style:hover > .u-border-hover-custom-color-5,
        a.u-button-style.u-border-hover-custom-color-5:focus,
        a.u-button-style.u-button-style.u-border-active-custom-color-5:active,
        a.u-button-style.u-button-style.u-border-active-custom-color-5.active,
        a.u-button-style.u-button-style.active > .u-border-active-custom-color-5,
        li.active > a.u-button-style.u-button-style.u-border-active-custom-color-5
        {
            color: var(--custom-color-5) !important;
            border-color: var(--custom-color-5) !important;
        }

        .u-link.u-border-custom-color-5[class*="u-border-"]
        {
            border-color: var(--custom-color-5) !important;
        }

        .u-link.u-border-custom-color-5[class*="u-border-"]:hover
        {
            border-color: var(--custom-color-5-darker) !important;
        }
        
        
        .u-border-custom-color-6,
        .u-separator-custom-color-6:after
        {
            border-color: var(--custom-color-6);
            stroke: var(--custom-color-6);
        }

        .u-button-style.u-border-custom-color-6
        {
            border-color: var(--custom-color-6) !important;
            color: var(--custom-color-6) !important;
            background-color: transparent !important;
        }

        .u-button-style.u-border-custom-color-6:hover,
        .u-button-style.u-border-custom-color-6:focus
        {
            border-color: transparent !important;
            color: var(--custom-color-6-darker) !important;
            background-color: transparent !important;
        }

        .u-border-hover-custom-color-6:hover,
        .u-border-hover-custom-color-6:focus,
        .u-border-active-custom-color-6.u-active.u-active,
        a.u-button-style.u-border-hover-custom-color-6:hover,
        a.u-button-style:hover > .u-border-hover-custom-color-6,
        a.u-button-style.u-border-hover-custom-color-6:focus,
        a.u-button-style.u-button-style.u-border-active-custom-color-6:active,
        a.u-button-style.u-button-style.u-border-active-custom-color-6.active,
        a.u-button-style.u-button-style.active > .u-border-active-custom-color-6,
        li.active > a.u-button-style.u-button-style.u-border-active-custom-color-6
        {
            color: var(--custom-color-6) !important;
            border-color: var(--custom-color-6) !important;
        }

        .u-link.u-border-custom-color-6[class*="u-border-"]
        {
            border-color: var(--custom-color-6) !important;
        }

        .u-link.u-border-custom-color-6[class*="u-border-"]:hover
        {
            border-color: var(--custom-color-6-darker) !important;
        }
        

        
        .u-text-custom-color-1,
        a.u-button-style.u-text-custom-color-1,
        a.u-button-style.u-text-custom-color-1[class*="u-border-"]
        {
            color: var(--custom-color-1) !important;
        }

        a.u-button-style.u-text-custom-color-1:hover,
        a.u-button-style.u-text-custom-color-1[class*="u-border-"]:hover,
        a.u-button-style.u-text-custom-color-1:focus,
        a.u-button-style.u-text-custom-color-1[class*="u-border-"]:focus,
        a.u-button-style.u-button-style.u-text-custom-color-1:active,
        a.u-button-style.u-button-style.u-text-custom-color-1[class*="u-border-"]:active,
        a.u-button-style.u-button-style.u-text-custom-color-1.active,
        a.u-button-style.u-button-style.u-text-custom-color-1[class*="u-border-"].active
        {
            color: var(--custom-color-1-darker) !important;
        }

        a.u-button-style:hover > .u-text-hover-custom-color-1,
        a.u-button-style:hover > .u-text-hover-custom-color-1[class*="u-border-"],
        a.u-button-style.u-button-style.u-text-hover-custom-color-1:hover,
        a.u-button-style.u-button-style.u-text-hover-custom-color-1[class*="u-border-"]:hover,
        a.u-button-style.u-button-style.u-text-hover-custom-color-1:focus,
        a.u-button-style.u-button-style.u-text-hover-custom-color-1[class*="u-border-"]:focus,
        a.u-button-style.u-button-style.u-button-style.u-text-active-custom-color-1:active,
        a.u-button-style.u-button-style.u-button-style.u-text-active-custom-color-1[class*="u-border-"]:active,
        a.u-button-style.u-button-style.u-button-style.u-text-active-custom-color-1.active,
        a.u-button-style.u-button-style.u-button-style.u-text-active-custom-color-1[class*="u-border-"].active,
        a.u-button-style.u-button-style.active > .u-text-active-custom-color-1,
        a.u-button-style.u-button-style.active > .u-text-active-custom-color-1[class*="u-border-"],
        :not(.level-2) > .u-nav > .u-nav-item > a.u-nav-link.u-text-hover-custom-color-1:hover,
        :not(.level-2) > .u-nav > .u-nav-item > a.u-nav-link.u-nav-link.u-text-active-custom-color-1.active,
        .u-popupmenu-items.u-text-hover-custom-color-1 .u-nav-link:hover,
        .u-popupmenu-items.u-popupmenu-items.u-text-active-custom-color-1 .u-nav-link.active
        {
            color: var(--custom-color-1) !important;
        }

        .u-text-custom-color-1 svg,
        .u-text-hover-custom-color-1:hover svg,
        .u-button-style:hover > .u-text-hover-custom-color-1 svg,
        .u-button-style.u-button-style.active > .u-text-active-custom-color-1 svg,
        .u-text-hover-custom-color-1:focus svg
        {
            fill: var(--custom-color-1);
        }

        .u-link.u-text-custom-color-1:hover
        {
            color: var(--custom-color-1-darker) !important;
        }

        a.u-link.u-text-hover-custom-color-1:hover
        {
            color: var(--custom-color-1) !important;
        }
        
        
        .u-text-custom-color-2,
        a.u-button-style.u-text-custom-color-2,
        a.u-button-style.u-text-custom-color-2[class*="u-border-"]
        {
            color: var(--custom-color-2) !important;
        }

        a.u-button-style.u-text-custom-color-2:hover,
        a.u-button-style.u-text-custom-color-2[class*="u-border-"]:hover,
        a.u-button-style.u-text-custom-color-2:focus,
        a.u-button-style.u-text-custom-color-2[class*="u-border-"]:focus,
        a.u-button-style.u-button-style.u-text-custom-color-2:active,
        a.u-button-style.u-button-style.u-text-custom-color-2[class*="u-border-"]:active,
        a.u-button-style.u-button-style.u-text-custom-color-2.active,
        a.u-button-style.u-button-style.u-text-custom-color-2[class*="u-border-"].active
        {
            color: var(--custom-color-2-darker) !important;
        }

        a.u-button-style:hover > .u-text-hover-custom-color-2,
        a.u-button-style:hover > .u-text-hover-custom-color-2[class*="u-border-"],
        a.u-button-style.u-button-style.u-text-hover-custom-color-2:hover,
        a.u-button-style.u-button-style.u-text-hover-custom-color-2[class*="u-border-"]:hover,
        a.u-button-style.u-button-style.u-text-hover-custom-color-2:focus,
        a.u-button-style.u-button-style.u-text-hover-custom-color-2[class*="u-border-"]:focus,
        a.u-button-style.u-button-style.u-button-style.u-text-active-custom-color-2:active,
        a.u-button-style.u-button-style.u-button-style.u-text-active-custom-color-2[class*="u-border-"]:active,
        a.u-button-style.u-button-style.u-button-style.u-text-active-custom-color-2.active,
        a.u-button-style.u-button-style.u-button-style.u-text-active-custom-color-2[class*="u-border-"].active,
        a.u-button-style.u-button-style.active > .u-text-active-custom-color-2,
        a.u-button-style.u-button-style.active > .u-text-active-custom-color-2[class*="u-border-"],
        :not(.level-2) > .u-nav > .u-nav-item > a.u-nav-link.u-text-hover-custom-color-2:hover,
        :not(.level-2) > .u-nav > .u-nav-item > a.u-nav-link.u-nav-link.u-text-active-custom-color-2.active,
        .u-popupmenu-items.u-text-hover-custom-color-2 .u-nav-link:hover,
        .u-popupmenu-items.u-popupmenu-items.u-text-active-custom-color-2 .u-nav-link.active
        {
            color: var(--custom-color-2) !important;
        }

        .u-text-custom-color-2 svg,
        .u-text-hover-custom-color-2:hover svg,
        .u-button-style:hover > .u-text-hover-custom-color-2 svg,
        .u-button-style.u-button-style.active > .u-text-active-custom-color-2 svg,
        .u-text-hover-custom-color-2:focus svg
        {
            fill: var(--custom-color-2);
        }

        .u-link.u-text-custom-color-2:hover
        {
            color: var(--custom-color-2-darker) !important;
        }

        a.u-link.u-text-hover-custom-color-2:hover
        {
            color: var(--custom-color-2) !important;
        }
        
        
        .u-text-custom-color-3,
        a.u-button-style.u-text-custom-color-3,
        a.u-button-style.u-text-custom-color-3[class*="u-border-"]
        {
            color: var(--custom-color-3) !important;
        }

        a.u-button-style.u-text-custom-color-3:hover,
        a.u-button-style.u-text-custom-color-3[class*="u-border-"]:hover,
        a.u-button-style.u-text-custom-color-3:focus,
        a.u-button-style.u-text-custom-color-3[class*="u-border-"]:focus,
        a.u-button-style.u-button-style.u-text-custom-color-3:active,
        a.u-button-style.u-button-style.u-text-custom-color-3[class*="u-border-"]:active,
        a.u-button-style.u-button-style.u-text-custom-color-3.active,
        a.u-button-style.u-button-style.u-text-custom-color-3[class*="u-border-"].active
        {
            color: var(--custom-color-3-darker) !important;
        }

        a.u-button-style:hover > .u-text-hover-custom-color-3,
        a.u-button-style:hover > .u-text-hover-custom-color-3[class*="u-border-"],
        a.u-button-style.u-button-style.u-text-hover-custom-color-3:hover,
        a.u-button-style.u-button-style.u-text-hover-custom-color-3[class*="u-border-"]:hover,
        a.u-button-style.u-button-style.u-text-hover-custom-color-3:focus,
        a.u-button-style.u-button-style.u-text-hover-custom-color-3[class*="u-border-"]:focus,
        a.u-button-style.u-button-style.u-button-style.u-text-active-custom-color-3:active,
        a.u-button-style.u-button-style.u-button-style.u-text-active-custom-color-3[class*="u-border-"]:active,
        a.u-button-style.u-button-style.u-button-style.u-text-active-custom-color-3.active,
        a.u-button-style.u-button-style.u-button-style.u-text-active-custom-color-3[class*="u-border-"].active,
        a.u-button-style.u-button-style.active > .u-text-active-custom-color-3,
        a.u-button-style.u-button-style.active > .u-text-active-custom-color-3[class*="u-border-"],
        :not(.level-2) > .u-nav > .u-nav-item > a.u-nav-link.u-text-hover-custom-color-3:hover,
        :not(.level-2) > .u-nav > .u-nav-item > a.u-nav-link.u-nav-link.u-text-active-custom-color-3.active,
        .u-popupmenu-items.u-text-hover-custom-color-3 .u-nav-link:hover,
        .u-popupmenu-items.u-popupmenu-items.u-text-active-custom-color-3 .u-nav-link.active
        {
            color: var(--custom-color-3) !important;
        }

        .u-text-custom-color-3 svg,
        .u-text-hover-custom-color-3:hover svg,
        .u-button-style:hover > .u-text-hover-custom-color-3 svg,
        .u-button-style.u-button-style.active > .u-text-active-custom-color-3 svg,
        .u-text-hover-custom-color-3:focus svg
        {
            fill: var(--custom-color-3);
        }

        .u-link.u-text-custom-color-3:hover
        {
            color: var(--custom-color-3-darker) !important;
        }

        a.u-link.u-text-hover-custom-color-3:hover
        {
            color: var(--custom-color-3) !important;
        }
        
        
        .u-text-custom-color-4,
        a.u-button-style.u-text-custom-color-4,
        a.u-button-style.u-text-custom-color-4[class*="u-border-"]
        {
            color: var(--custom-color-4) !important;
        }

        a.u-button-style.u-text-custom-color-4:hover,
        a.u-button-style.u-text-custom-color-4[class*="u-border-"]:hover,
        a.u-button-style.u-text-custom-color-4:focus,
        a.u-button-style.u-text-custom-color-4[class*="u-border-"]:focus,
        a.u-button-style.u-button-style.u-text-custom-color-4:active,
        a.u-button-style.u-button-style.u-text-custom-color-4[class*="u-border-"]:active,
        a.u-button-style.u-button-style.u-text-custom-color-4.active,
        a.u-button-style.u-button-style.u-text-custom-color-4[class*="u-border-"].active
        {
            color: var(--custom-color-4-darker) !important;
        }

        a.u-button-style:hover > .u-text-hover-custom-color-4,
        a.u-button-style:hover > .u-text-hover-custom-color-4[class*="u-border-"],
        a.u-button-style.u-button-style.u-text-hover-custom-color-4:hover,
        a.u-button-style.u-button-style.u-text-hover-custom-color-4[class*="u-border-"]:hover,
        a.u-button-style.u-button-style.u-text-hover-custom-color-4:focus,
        a.u-button-style.u-button-style.u-text-hover-custom-color-4[class*="u-border-"]:focus,
        a.u-button-style.u-button-style.u-button-style.u-text-active-custom-color-4:active,
        a.u-button-style.u-button-style.u-button-style.u-text-active-custom-color-4[class*="u-border-"]:active,
        a.u-button-style.u-button-style.u-button-style.u-text-active-custom-color-4.active,
        a.u-button-style.u-button-style.u-button-style.u-text-active-custom-color-4[class*="u-border-"].active,
        a.u-button-style.u-button-style.active > .u-text-active-custom-color-4,
        a.u-button-style.u-button-style.active > .u-text-active-custom-color-4[class*="u-border-"],
        :not(.level-2) > .u-nav > .u-nav-item > a.u-nav-link.u-text-hover-custom-color-4:hover,
        :not(.level-2) > .u-nav > .u-nav-item > a.u-nav-link.u-nav-link.u-text-active-custom-color-4.active,
        .u-popupmenu-items.u-text-hover-custom-color-4 .u-nav-link:hover,
        .u-popupmenu-items.u-popupmenu-items.u-text-active-custom-color-4 .u-nav-link.active
        {
            color: var(--custom-color-4) !important;
        }

        .u-text-custom-color-4 svg,
        .u-text-hover-custom-color-4:hover svg,
        .u-button-style:hover > .u-text-hover-custom-color-4 svg,
        .u-button-style.u-button-style.active > .u-text-active-custom-color-4 svg,
        .u-text-hover-custom-color-4:focus svg
        {
            fill: var(--custom-color-4);
        }

        .u-link.u-text-custom-color-4:hover
        {
            color: var(--custom-color-4-darker) !important;
        }

        a.u-link.u-text-hover-custom-color-4:hover
        {
            color: var(--custom-color-4) !important;
        }
        
        
        .u-text-custom-color-5,
        a.u-button-style.u-text-custom-color-5,
        a.u-button-style.u-text-custom-color-5[class*="u-border-"]
        {
            color: var(--custom-color-5) !important;
        }

        a.u-button-style.u-text-custom-color-5:hover,
        a.u-button-style.u-text-custom-color-5[class*="u-border-"]:hover,
        a.u-button-style.u-text-custom-color-5:focus,
        a.u-button-style.u-text-custom-color-5[class*="u-border-"]:focus,
        a.u-button-style.u-button-style.u-text-custom-color-5:active,
        a.u-button-style.u-button-style.u-text-custom-color-5[class*="u-border-"]:active,
        a.u-button-style.u-button-style.u-text-custom-color-5.active,
        a.u-button-style.u-button-style.u-text-custom-color-5[class*="u-border-"].active
        {
            color: var(--custom-color-5-darker) !important;
        }

        a.u-button-style:hover > .u-text-hover-custom-color-5,
        a.u-button-style:hover > .u-text-hover-custom-color-5[class*="u-border-"],
        a.u-button-style.u-button-style.u-text-hover-custom-color-5:hover,
        a.u-button-style.u-button-style.u-text-hover-custom-color-5[class*="u-border-"]:hover,
        a.u-button-style.u-button-style.u-text-hover-custom-color-5:focus,
        a.u-button-style.u-button-style.u-text-hover-custom-color-5[class*="u-border-"]:focus,
        a.u-button-style.u-button-style.u-button-style.u-text-active-custom-color-5:active,
        a.u-button-style.u-button-style.u-button-style.u-text-active-custom-color-5[class*="u-border-"]:active,
        a.u-button-style.u-button-style.u-button-style.u-text-active-custom-color-5.active,
        a.u-button-style.u-button-style.u-button-style.u-text-active-custom-color-5[class*="u-border-"].active,
        a.u-button-style.u-button-style.active > .u-text-active-custom-color-5,
        a.u-button-style.u-button-style.active > .u-text-active-custom-color-5[class*="u-border-"],
        :not(.level-2) > .u-nav > .u-nav-item > a.u-nav-link.u-text-hover-custom-color-5:hover,
        :not(.level-2) > .u-nav > .u-nav-item > a.u-nav-link.u-nav-link.u-text-active-custom-color-5.active,
        .u-popupmenu-items.u-text-hover-custom-color-5 .u-nav-link:hover,
        .u-popupmenu-items.u-popupmenu-items.u-text-active-custom-color-5 .u-nav-link.active
        {
            color: var(--custom-color-5) !important;
        }

        .u-text-custom-color-5 svg,
        .u-text-hover-custom-color-5:hover svg,
        .u-button-style:hover > .u-text-hover-custom-color-5 svg,
        .u-button-style.u-button-style.active > .u-text-active-custom-color-5 svg,
        .u-text-hover-custom-color-5:focus svg
        {
            fill: var(--custom-color-5);
        }

        .u-link.u-text-custom-color-5:hover
        {
            color: var(--custom-color-5-darker) !important;
        }

        a.u-link.u-text-hover-custom-color-5:hover
        {
            color: var(--custom-color-5) !important;
        }
        
        
        .u-text-custom-color-6,
        a.u-button-style.u-text-custom-color-6,
        a.u-button-style.u-text-custom-color-6[class*="u-border-"]
        {
            color: var(--custom-color-6) !important;
        }

        a.u-button-style.u-text-custom-color-6:hover,
        a.u-button-style.u-text-custom-color-6[class*="u-border-"]:hover,
        a.u-button-style.u-text-custom-color-6:focus,
        a.u-button-style.u-text-custom-color-6[class*="u-border-"]:focus,
        a.u-button-style.u-button-style.u-text-custom-color-6:active,
        a.u-button-style.u-button-style.u-text-custom-color-6[class*="u-border-"]:active,
        a.u-button-style.u-button-style.u-text-custom-color-6.active,
        a.u-button-style.u-button-style.u-text-custom-color-6[class*="u-border-"].active
        {
            color: var(--custom-color-6-darker) !important;
        }

        a.u-button-style:hover > .u-text-hover-custom-color-6,
        a.u-button-style:hover > .u-text-hover-custom-color-6[class*="u-border-"],
        a.u-button-style.u-button-style.u-text-hover-custom-color-6:hover,
        a.u-button-style.u-button-style.u-text-hover-custom-color-6[class*="u-border-"]:hover,
        a.u-button-style.u-button-style.u-text-hover-custom-color-6:focus,
        a.u-button-style.u-button-style.u-text-hover-custom-color-6[class*="u-border-"]:focus,
        a.u-button-style.u-button-style.u-button-style.u-text-active-custom-color-6:active,
        a.u-button-style.u-button-style.u-button-style.u-text-active-custom-color-6[class*="u-border-"]:active,
        a.u-button-style.u-button-style.u-button-style.u-text-active-custom-color-6.active,
        a.u-button-style.u-button-style.u-button-style.u-text-active-custom-color-6[class*="u-border-"].active,
        a.u-button-style.u-button-style.active > .u-text-active-custom-color-6,
        a.u-button-style.u-button-style.active > .u-text-active-custom-color-6[class*="u-border-"],
        :not(.level-2) > .u-nav > .u-nav-item > a.u-nav-link.u-text-hover-custom-color-6:hover,
        :not(.level-2) > .u-nav > .u-nav-item > a.u-nav-link.u-nav-link.u-text-active-custom-color-6.active,
        .u-popupmenu-items.u-text-hover-custom-color-6 .u-nav-link:hover,
        .u-popupmenu-items.u-popupmenu-items.u-text-active-custom-color-6 .u-nav-link.active
        {
            color: var(--custom-color-6) !important;
        }

        .u-text-custom-color-6 svg,
        .u-text-hover-custom-color-6:hover svg,
        .u-button-style:hover > .u-text-hover-custom-color-6 svg,
        .u-button-style.u-button-style.active > .u-text-active-custom-color-6 svg,
        .u-text-hover-custom-color-6:focus svg
        {
            fill: var(--custom-color-6);
        }

        .u-link.u-text-custom-color-6:hover
        {
            color: var(--custom-color-6-darker) !important;
        }

        a.u-link.u-text-hover-custom-color-6:hover
        {
            color: var(--custom-color-6) !important;
        }</style><style id="typography" typography="custom-page-typography-1">
        .u-body
        {
        --title-font-size: 6rem;
        --title-line-height: 1.1;
        --title-margin-top: 20px;
        --title-margin-bottom: 20px;
        --title-font-family: Roboto,sans-serif;
        --title-color: var(--body-color);
        --title-font-weight: 400;
        --title-alt-text-color: var(--body-alt-color);
        --subtitle-font-size: 4.5rem;
        --subtitle-line-height: 1.1;
        --subtitle-margin-top: 20px;
        --subtitle-margin-bottom: 20px;
        --subtitle-font-weight: 700;
        --subtitle-text-transform: uppercase;
        --subtitle-font-family: Ubuntu,sans-serif;
        --h1-font-weight: 400;
        --h1-font-size: 3rem;
        --h1-line-height: 1.1;
        --h1-margin-top: 20px;
        --h1-margin-bottom: 20px;
        --h2-font-size: 1.875rem;
        --h2-line-height: 1.1;
        --h2-margin-top: 20px;
        --h2-margin-bottom: 20px;
        --h2-text-transform: uppercase;
        --h2-font-family: Ubuntu,sans-serif;
        --h2-font-weight: 700;
        --h3-font-size: 4.5rem;
        --h3-line-height: 1.2;
        --h3-margin-top: 20px;
        --h3-margin-bottom: 20px;
        --h3-font-family: Ubuntu,sans-serif;
        --h3-text-transform: uppercase;
        --h3-letter-spacing: 5px;
        --h3-color: var(--body-alt-color);
        --h3-font-weight: 700;
        --h3-list-icon-spacing: 0.3;
        --h3-list-icon-size: 0.8;
        --h3-alt-text-color: var(--body-color);
        --h4-font-size: 1.5rem;
        --h4-line-height: 1.2;
        --h4-margin-top: 20px;
        --h4-margin-bottom: 20px;
        --h4-font-family: Ubuntu,sans-serif;
        --h4-font-weight: 700;
        --h4-text-transform: uppercase;
        --h5-font-weight: 400;
        --h5-font-size: 1.25rem;
        --h5-line-height: 1.2;
        --h5-margin-top: 20px;
        --h5-margin-bottom: 20px;
        --h6-font-weight: 400;
        --h6-font-size: 1.125rem;
        --h6-line-height: 1.2;
        --h6-margin-top: 20px;
        --h6-margin-bottom: 20px;
        --largeText-font-size: 1.25rem;
        --largeText-margin-top: 20px;
        --largeText-margin-bottom: 20px;
        --smallText-font-size: 0.875rem;
        --smallText-margin-top: 20px;
        --smallText-margin-bottom: 20px;
        --text-margin-top: 20px;
        --text-margin-bottom: 20px;
        --button-margin-top: 20px;
        --button-margin-bottom: 20px;
        --button-background-color: var(--palette-1-base);
        --button-color: var(--white);
        --button-alt-background-color: var(--palette-1-light-2);
        --button-alt-color: var(--black);
        --button-hover-background-color: var(--palette-1-base-darker);
        --button-hover-color: var(--white-darker);
        --button-hover-alt-background-color: var(--palette-1-light-2-darker);
        --button-hover-alt-color: var(--white);
        --button-hover-background-color: var(--palette-1-base-darker);
        --button-hover-color: var(--white-darker);
        --button-hover-alt-background-color: var(--palette-1-light-2-darker);
        --button-hover-alt-color: var(--white);
        --button-active-background-color: var(--palette-1-base-darker);
        --button-active-color: var(--white-darker);
        --button-active-alt-background-color: var(--palette-1-light-2-darker);
        --button-active-alt-color: var(--white);
        --blockquote-font-style: italic;
        --blockquote-padding-left: 20px;
        --blockquote-border-width: 4px;
        --blockquote-border-color: var(--palette-1-base);
        --blockquote-margin-top: 20px;
        --blockquote-margin-bottom: 20px;
        --metadata-margin-top: 20px;
        --metadata-margin-bottom: 20px;
        --list-margin-top: 20px;
        --list-margin-bottom: 20px;
        --orderedlist-margin-top: 20px;
        --orderedlist-margin-bottom: 20px;
        --postContent-margin-top: 20px;
        --postContent-margin-bottom: 20px;
        --hyperlink-color: var(--palette-1-base);
        --hyperlink-alt-text-color: var(--palette-1-light-2);
        --hyperlink-hover-color: var(--palette-1-base-darker);
        --hyperlink-hover-alt-text-color: var(--grey-30-darker);
        }

        /** common-rules **/
        h1.u-title
        {
        font-size: var(--title-font-size);
        line-height: var(--title-line-height);
        margin-top: var(--title-margin-top);
        margin-bottom: var(--title-margin-bottom);
        font-family: var(--title-font-family);
        font-weight: var(--title-font-weight);
        }
        h2.u-subtitle
        {
        font-size: var(--subtitle-font-size);
        line-height: var(--subtitle-line-height);
        margin-top: var(--subtitle-margin-top);
        margin-bottom: var(--subtitle-margin-bottom);
        font-weight: var(--subtitle-font-weight);
        text-transform: var(--subtitle-text-transform);
        font-family: var(--subtitle-font-family);
        }
        h1:not(.u-title)
        {
        font-weight: var(--h1-font-weight);
        font-size: var(--h1-font-size);
        line-height: var(--h1-line-height);
        margin-top: var(--h1-margin-top);
        margin-bottom: var(--h1-margin-bottom);
        }
        h2:not(.u-subtitle)
        {
        font-size: var(--h2-font-size);
        line-height: var(--h2-line-height);
        margin-top: var(--h2-margin-top);
        margin-bottom: var(--h2-margin-bottom);
        text-transform: var(--h2-text-transform);
        font-family: var(--h2-font-family);
        font-weight: var(--h2-font-weight);
        }
        h3
        {
        font-size: var(--h3-font-size);
        line-height: var(--h3-line-height);
        margin-top: var(--h3-margin-top);
        margin-bottom: var(--h3-margin-bottom);
        font-family: var(--h3-font-family);
        text-transform: var(--h3-text-transform);
        letter-spacing: var(--h3-letter-spacing);
        font-weight: var(--h3-font-weight);
        list-icon-spacing: var(--h3-list-icon-spacing);
        list-icon-size: var(--h3-list-icon-size);
        }
        h4
        {
        font-size: var(--h4-font-size);
        line-height: var(--h4-line-height);
        margin-top: var(--h4-margin-top);
        margin-bottom: var(--h4-margin-bottom);
        font-family: var(--h4-font-family);
        font-weight: var(--h4-font-weight);
        text-transform: var(--h4-text-transform);
        }
        h5
        {
        font-weight: var(--h5-font-weight);
        font-size: var(--h5-font-size);
        line-height: var(--h5-line-height);
        margin-top: var(--h5-margin-top);
        margin-bottom: var(--h5-margin-bottom);
        }
        h6
        {
        font-weight: var(--h6-font-weight);
        font-size: var(--h6-font-size);
        line-height: var(--h6-line-height);
        margin-top: var(--h6-margin-top);
        margin-bottom: var(--h6-margin-bottom);
        }
        p.u-large-text
        {
        font-size: var(--largeText-font-size);
        margin-top: var(--largeText-margin-top);
        margin-bottom: var(--largeText-margin-bottom);
        }
        p.u-small-text
        {
        font-size: var(--smallText-font-size);
        margin-top: var(--smallText-margin-top);
        margin-bottom: var(--smallText-margin-bottom);
        }
        p:not(.u-text-variant)
        {
        margin-top: var(--text-margin-top);
        margin-bottom: var(--text-margin-bottom);
        }
        .u-btn
        {
        margin-top: var(--button-margin-top);
        margin-bottom: var(--button-margin-bottom);
        }
        blockquote
        {
        font-style: var(--blockquote-font-style);
        padding-left: var(--blockquote-padding-left);
        border-width: var(--blockquote-border-width);
        margin-top: var(--blockquote-margin-top);
        margin-bottom: var(--blockquote-margin-bottom);
        }
        .u-metadata
        {
        margin-top: var(--metadata-margin-top);
        margin-bottom: var(--metadata-margin-bottom);
        }
        ul:not(.u-unstyled)
        {
        margin-top: var(--list-margin-top);
        margin-bottom: var(--list-margin-bottom);
        }
        ol
        {
        margin-top: var(--orderedlist-margin-top);
        margin-bottom: var(--orderedlist-margin-bottom);
        }
        .u-post-content
        {
        margin-top: var(--postContent-margin-top);
        margin-bottom: var(--postContent-margin-bottom);
        }
        /** common-rules **/

        /** publish-rules **/
        /*begin-media rules*/
        /*end-media rules*/
        /** publish-rules **/

        

        /** cms-rules **/
        /*begin-responsive rules*/
        /*end-responsive rules*/
        /** cms-rules **/

        /** color-rules **/
        .u-overlap.u-overlap-transparent:not(.u-overlap-contrast) .u-header :not(.u-nav-item) > h1.u-title,
        .u-gradient > .u-container-layout > h1.u-title,
        .u-image:not(.u-shading) > .u-container-layout > h1.u-title,
        h1.u-title
        {
        color: var(--title-color);
        }
        .u-overlap.u-overlap-transparent:not(.u-overlap-contrast) .u-header :not(.u-nav-item) > h3,
        .u-gradient > .u-container-layout > h3,
        .u-image:not(.u-shading) > .u-container-layout > h3,
        h3
        {
        color: var(--h3-color);
        }
        .u-overlap.u-overlap-transparent:not(.u-overlap-contrast) .u-header :not(.u-nav-item) > .u-btn,
        .u-gradient > .u-container-layout > .u-btn,
        .u-image:not(.u-shading) > .u-container-layout > .u-btn,
        .u-btn
        {
        background-color: var(--button-background-color);
        color: var(--button-color);
        }
        .u-overlap.u-overlap-transparent:not(.u-overlap-contrast) .u-header :not(.u-nav-item) > .u-btn:hover,
        .u-gradient > .u-container-layout > .u-btn:hover,
        .u-image:not(.u-shading) > .u-container-layout > .u-btn:hover,
        .u-btn:hover
        {
        background-color: var(--button-hover-background-color);
        color: var(--button-hover-color);
        }
        .u-overlap.u-overlap-transparent:not(.u-overlap-contrast) .u-header :not(.u-nav-item) > .u-btn:focus,
        .u-gradient > .u-container-layout > .u-btn:focus,
        .u-image:not(.u-shading) > .u-container-layout > .u-btn:focus,
        .u-btn:focus
        {
        background-color: var(--button-hover-background-color);
        color: var(--button-hover-color);
        }
        .u-overlap.u-overlap-transparent:not(.u-overlap-contrast) .u-header :not(.u-nav-item) > .u-btn:active,
        .u-gradient > .u-container-layout > .u-btn:active,
        .u-image:not(.u-shading) > .u-container-layout > .u-btn:active,
        .u-btn:active
        {
        background-color: var(--button-active-background-color);
        color: var(--button-active-color);
        }
        .u-overlap.u-overlap-transparent:not(.u-overlap-contrast) .u-header :not(.u-nav-item) > blockquote,
        .u-gradient > .u-container-layout > blockquote,
        .u-image:not(.u-shading) > .u-container-layout > blockquote,
        blockquote
        {
        border-color: var(--blockquote-border-color);
        }
        .u-overlap.u-overlap-transparent:not(.u-overlap-contrast) .u-header :not(.u-nav-item) > a,
        .u-gradient > .u-container-layout > a,
        .u-image:not(.u-shading) > .u-container-layout > a,
        a
        {
        color: var(--hyperlink-color);
        }
        .u-overlap.u-overlap-transparent:not(.u-overlap-contrast) .u-header :not(.u-nav-item) > a:hover,
        .u-gradient > .u-container-layout > a:hover,
        .u-image:not(.u-shading) > .u-container-layout > a:hover,
        a:hover
        {
        color: var(--hyperlink-hover-color);
        }
        /** color-rules **/

        /** alt-color-rules **/
        .u-custom-color-1 h1.u-title,.u-custom-color-2 h1.u-title,.u-custom-color-3 h1.u-title,.u-custom-color-4 h1.u-title,.u-custom-color-5 h1.u-title,.u-custom-color-6 h1.u-title,.u-body-color h1.u-title,.u-palette-1-base h1.u-title,.u-palette-1-dark-3 h1.u-title,.u-palette-1-dark-2 h1.u-title,.u-palette-1-dark-1 h1.u-title,.u-palette-1 h1.u-title,.u-palette-1-light-1 h1.u-title,.u-palette-2-base h1.u-title,.u-palette-2-dark-3 h1.u-title,.u-palette-2-dark-2 h1.u-title,.u-palette-2-dark-1 h1.u-title,.u-palette-2 h1.u-title,.u-palette-2-light-1 h1.u-title,.u-palette-3-base h1.u-title,.u-palette-3-dark-3 h1.u-title,.u-palette-3-dark-2 h1.u-title,.u-palette-3-dark-1 h1.u-title,.u-palette-3 h1.u-title,.u-palette-4-dark-3 h1.u-title,.u-palette-4-dark-2 h1.u-title,.u-palette-4-dark-1 h1.u-title,.u-palette-4 h1.u-title,.u-palette-5-dark-3 h1.u-title,.u-palette-5-dark-2 h1.u-title,.u-palette-5-dark-1 h1.u-title,.u-grey-40 h1.u-title,.u-grey-30 h1.u-title,.u-grey-90 h1.u-title,.u-grey-80 h1.u-title,.u-grey-75 h1.u-title,.u-black h1.u-title,.u-grey-70 h1.u-title,.u-grey-60 h1.u-title,.u-grey-50 h1.u-title,.u-grey-dark-3 h1.u-title,.u-grey-dark-2 h1.u-title,.u-grey-dark-1 h1.u-title,.u-grey h1.u-title,.u-shading h1.u-title,.u-overlap-contrast .u-header h1.u-title:not(.u-nav-link):not(.u-btn)
        {
        color: var(--title-alt-text-color);
        }
        .u-shading h3,.u-overlap-contrast .u-header h3:not(.u-nav-link):not(.u-btn)
        {
        color: var(--h3-alt-text-color);
        }
        .u-custom-color-1 .u-btn,.u-custom-color-2 .u-btn,.u-custom-color-3 .u-btn,.u-custom-color-4 .u-btn,.u-custom-color-5 .u-btn,.u-custom-color-6 .u-btn,.u-body-color .u-btn,.u-palette-1-base .u-btn,.u-palette-1-dark-3 .u-btn,.u-palette-1-dark-2 .u-btn,.u-palette-1-dark-1 .u-btn,.u-palette-1 .u-btn,.u-palette-1-light-1 .u-btn,.u-palette-2-base .u-btn,.u-palette-2-dark-3 .u-btn,.u-palette-2-dark-2 .u-btn,.u-palette-2-dark-1 .u-btn,.u-palette-2 .u-btn,.u-palette-2-light-1 .u-btn,.u-palette-3-base .u-btn,.u-palette-3-dark-3 .u-btn,.u-palette-3-dark-2 .u-btn,.u-palette-3-dark-1 .u-btn,.u-palette-3 .u-btn,.u-palette-4-dark-3 .u-btn,.u-palette-4-dark-2 .u-btn,.u-palette-4-dark-1 .u-btn,.u-palette-4 .u-btn,.u-palette-5-dark-3 .u-btn,.u-palette-5-dark-2 .u-btn,.u-palette-5-dark-1 .u-btn,.u-grey-40 .u-btn,.u-grey-30 .u-btn,.u-grey-90 .u-btn,.u-grey-80 .u-btn,.u-grey-75 .u-btn,.u-black .u-btn,.u-grey-70 .u-btn,.u-grey-60 .u-btn,.u-grey-50 .u-btn,.u-grey-dark-3 .u-btn,.u-grey-dark-2 .u-btn,.u-grey-dark-1 .u-btn,.u-grey .u-btn,.u-shading .u-btn,.u-overlap-contrast .u-header .u-btn
        {
        background-color: var(--button-alt-background-color);
        color: var(--button-alt-color);
        }
        .u-custom-color-1 .u-btn:hover,.u-custom-color-2 .u-btn:hover,.u-custom-color-3 .u-btn:hover,.u-custom-color-4 .u-btn:hover,.u-custom-color-5 .u-btn:hover,.u-custom-color-6 .u-btn:hover,.u-body-color .u-btn:hover,.u-palette-1-base .u-btn:hover,.u-palette-1-dark-3 .u-btn:hover,.u-palette-1-dark-2 .u-btn:hover,.u-palette-1-dark-1 .u-btn:hover,.u-palette-1 .u-btn:hover,.u-palette-1-light-1 .u-btn:hover,.u-palette-2-base .u-btn:hover,.u-palette-2-dark-3 .u-btn:hover,.u-palette-2-dark-2 .u-btn:hover,.u-palette-2-dark-1 .u-btn:hover,.u-palette-2 .u-btn:hover,.u-palette-2-light-1 .u-btn:hover,.u-palette-3-base .u-btn:hover,.u-palette-3-dark-3 .u-btn:hover,.u-palette-3-dark-2 .u-btn:hover,.u-palette-3-dark-1 .u-btn:hover,.u-palette-3 .u-btn:hover,.u-palette-4-dark-3 .u-btn:hover,.u-palette-4-dark-2 .u-btn:hover,.u-palette-4-dark-1 .u-btn:hover,.u-palette-4 .u-btn:hover,.u-palette-5-dark-3 .u-btn:hover,.u-palette-5-dark-2 .u-btn:hover,.u-palette-5-dark-1 .u-btn:hover,.u-grey-40 .u-btn:hover,.u-grey-30 .u-btn:hover,.u-grey-90 .u-btn:hover,.u-grey-80 .u-btn:hover,.u-grey-75 .u-btn:hover,.u-black .u-btn:hover,.u-grey-70 .u-btn:hover,.u-grey-60 .u-btn:hover,.u-grey-50 .u-btn:hover,.u-grey-dark-3 .u-btn:hover,.u-grey-dark-2 .u-btn:hover,.u-grey-dark-1 .u-btn:hover,.u-grey .u-btn:hover,.u-shading .u-btn:hover,.u-overlap-contrast .u-header .u-btn:hover
        {
        background-color: var(--button-hover-alt-background-color);
        color: var(--button-hover-alt-color);
        }
        .u-custom-color-1 .u-btn:active,.u-custom-color-2 .u-btn:active,.u-custom-color-3 .u-btn:active,.u-custom-color-4 .u-btn:active,.u-custom-color-5 .u-btn:active,.u-custom-color-6 .u-btn:active,.u-body-color .u-btn:active,.u-palette-1-base .u-btn:active,.u-palette-1-dark-3 .u-btn:active,.u-palette-1-dark-2 .u-btn:active,.u-palette-1-dark-1 .u-btn:active,.u-palette-1 .u-btn:active,.u-palette-1-light-1 .u-btn:active,.u-palette-2-base .u-btn:active,.u-palette-2-dark-3 .u-btn:active,.u-palette-2-dark-2 .u-btn:active,.u-palette-2-dark-1 .u-btn:active,.u-palette-2 .u-btn:active,.u-palette-2-light-1 .u-btn:active,.u-palette-3-base .u-btn:active,.u-palette-3-dark-3 .u-btn:active,.u-palette-3-dark-2 .u-btn:active,.u-palette-3-dark-1 .u-btn:active,.u-palette-3 .u-btn:active,.u-palette-4-dark-3 .u-btn:active,.u-palette-4-dark-2 .u-btn:active,.u-palette-4-dark-1 .u-btn:active,.u-palette-4 .u-btn:active,.u-palette-5-dark-3 .u-btn:active,.u-palette-5-dark-2 .u-btn:active,.u-palette-5-dark-1 .u-btn:active,.u-grey-40 .u-btn:active,.u-grey-30 .u-btn:active,.u-grey-90 .u-btn:active,.u-grey-80 .u-btn:active,.u-grey-75 .u-btn:active,.u-black .u-btn:active,.u-grey-70 .u-btn:active,.u-grey-60 .u-btn:active,.u-grey-50 .u-btn:active,.u-grey-dark-3 .u-btn:active,.u-grey-dark-2 .u-btn:active,.u-grey-dark-1 .u-btn:active,.u-grey .u-btn:active,.u-shading .u-btn:active,.u-overlap-contrast .u-header .u-btn:active
        {
        background-color: var(--button-active-alt-background-color);
        color: var(--button-active-alt-color);
        }
        .u-custom-color-1 a,.u-custom-color-2 a,.u-custom-color-3 a,.u-custom-color-4 a,.u-custom-color-5 a,.u-custom-color-6 a,.u-body-color a,.u-palette-1-base a,.u-palette-1-dark-3 a,.u-palette-1-dark-2 a,.u-palette-1-dark-1 a,.u-palette-1 a,.u-palette-1-light-1 a,.u-palette-2-base a,.u-palette-2-dark-3 a,.u-palette-2-dark-2 a,.u-palette-2-dark-1 a,.u-palette-2 a,.u-palette-2-light-1 a,.u-palette-3-base a,.u-palette-3-dark-3 a,.u-palette-3-dark-2 a,.u-palette-3-dark-1 a,.u-palette-3 a,.u-palette-4-dark-3 a,.u-palette-4-dark-2 a,.u-palette-4-dark-1 a,.u-palette-4 a,.u-palette-5-dark-3 a,.u-palette-5-dark-2 a,.u-palette-5-dark-1 a,.u-grey-40 a,.u-grey-30 a,.u-grey-90 a,.u-grey-80 a,.u-grey-75 a,.u-black a,.u-grey-70 a,.u-grey-60 a,.u-grey-50 a,.u-grey-dark-3 a,.u-grey-dark-2 a,.u-grey-dark-1 a,.u-grey a,.u-shading a,.u-overlap-contrast .u-header a:not(.u-nav-link):not(.u-btn)
        {
        color: var(--hyperlink-alt-text-color);
        }
        .u-custom-color-1 a:hover,.u-custom-color-2 a:hover,.u-custom-color-3 a:hover,.u-custom-color-4 a:hover,.u-custom-color-5 a:hover,.u-custom-color-6 a:hover,.u-body-color a:hover,.u-palette-1-base a:hover,.u-palette-1-dark-3 a:hover,.u-palette-1-dark-2 a:hover,.u-palette-1-dark-1 a:hover,.u-palette-1 a:hover,.u-palette-1-light-1 a:hover,.u-palette-2-base a:hover,.u-palette-2-dark-3 a:hover,.u-palette-2-dark-2 a:hover,.u-palette-2-dark-1 a:hover,.u-palette-2 a:hover,.u-palette-2-light-1 a:hover,.u-palette-3-base a:hover,.u-palette-3-dark-3 a:hover,.u-palette-3-dark-2 a:hover,.u-palette-3-dark-1 a:hover,.u-palette-3 a:hover,.u-palette-4-dark-3 a:hover,.u-palette-4-dark-2 a:hover,.u-palette-4-dark-1 a:hover,.u-palette-4 a:hover,.u-palette-5-dark-3 a:hover,.u-palette-5-dark-2 a:hover,.u-palette-5-dark-1 a:hover,.u-grey-40 a:hover,.u-grey-30 a:hover,.u-grey-90 a:hover,.u-grey-80 a:hover,.u-grey-75 a:hover,.u-black a:hover,.u-grey-70 a:hover,.u-grey-60 a:hover,.u-grey-50 a:hover,.u-grey-dark-3 a:hover,.u-grey-dark-2 a:hover,.u-grey-dark-1 a:hover,.u-grey a:hover
        {
        color: var(--hyperlink-hover-alt-text-color);
        }
        /** alt-color-rules **/
    </style><style id="font-scheme" font-scheme="custom-font-family-1" heading-font="Roboto,sans-serif" text-font="'Open Sans',sans-serif" font-subset="arabic">.u-body {
   --text-font: 'Open Sans',sans-serif;
   --heading-font: Roboto,sans-serif;
}</style>