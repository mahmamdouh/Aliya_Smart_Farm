<!-- header styles -->

<?php
   $localFonts = apply_filters('get_local_fonts', '');
?>
<?php if ($localFonts) : ?> 
   <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/<?php echo $localFonts; ?>" media="screen" type="text/css" />
<?php else : ?>
   <?php endif; ?>
<link id="u-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i|Ubuntu:300,300i,400,400i,500,500i,700,700i&subset=arabic">
<style>.u-header .u-section-row-1 {
  background-image: none;
}
.u-header .u-sheet-1 {
  min-height: 99px;
}
.u-header .u-social-icons-1 {
  white-space: nowrap;
  height: 32px;
  min-height: 16px;
  width: 74px;
  min-width: 42px;
  margin: 34px 0 0 auto;
}
.u-header .u-icon-1 {
  color: rgb(85, 172, 238) !important;
}
.u-header .u-icon-2 {
  color: rgb(197, 54, 164) !important;
}
.u-header .u-text-1 {
  margin: -28px 716px 38px 0;
}
@media (max-width: 1199px) {
  .u-header .u-social-icons-1 {
    width: 116px;
    min-width: 68px;
  }
  .u-header .u-text-1 {
    margin-top: -28px;
    margin-right: 516px;
  }
}
@media (max-width: 991px) {
  .u-header .u-text-1 {
    margin-right: 296px;
  }
}
@media (max-width: 767px) {
  .u-header .u-sheet-1 {
    min-height: 101px;
  }
  .u-header .u-text-1 {
    width: auto;
    margin-right: 233px;
    margin-bottom: 38px;
  }
}
@media (max-width: 575px) {
  .u-header .u-sheet-1 {
    min-height: 131px;
  }
  .u-header .u-social-icons-1 {
    margin-top: 27px;
    margin-right: auto;
  }
  .u-header .u-text-1 {
    margin: 20px 17px 27px;
  }
}
.u-header .u-sheet-2 {
  min-height: 99px;
}
.u-header .u-image-1 {
  width: 61px;
  height: 91px;
  margin: 0 auto 0 0;
}
.u-header .u-logo-image-1 {
  width: 100%;
  height: 100%;
}
.u-header .u-search-1 {
  width: 200px;
  min-height: 38px;
  height: auto;
  margin: -54px -12px 25px auto;
}
@media (max-width: 1199px) {
  .u-header .u-image-1 {
    width: 61px;
  }
  .u-header .u-search-1 {
    margin-top: -54px;
  }
}
.u-header .u-section-row-3 {
  background-image: none;
}
.u-header .u-sheet-3 {
  min-height: 84px;
}
.u-header .u-menu-1 {
  margin: 16px -35px;
}
.u-header .u-nav-1 {
  font-size: 1.5rem;
  letter-spacing: 0px;
  font-weight: 700;
  text-transform: none;
}
.u-block-c88c-30 {
  font-size: 1rem;
  letter-spacing: 0px;
  font-weight: 700;
  text-transform: none;
}
.u-header .u-nav-2 {
  font-size: 1rem;
  letter-spacing: 0px;
  font-weight: 700;
  text-transform: none;
}
.u-block-c88c-31 {
  font-size: 1rem;
  letter-spacing: 0px;
  font-weight: 700;
  text-transform: none;
}
@media (max-width: 1199px) {
  .u-header .u-menu-1 {
    margin-right: -35px;
    margin-left: -35px;
  }
}</style>
